<?php
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
$result=['ok'=>true,'php'=>PHP_VERSION,'encoding'=>'UTF-8','checks'=>[]];
try{
 require __DIR__.'/../api/config.php';
 $result['checks']['config']='ok';
 require __DIR__.'/../api/bootstrap.php';
 $migration=migrate_schema();
 $result['checks']['database']='ok';
 $result['checks']['migration']=$migration;
 $result['checks']['tables']=['spooky_places'=>table_exists('spooky_places'),'admin_users'=>table_exists('admin_users'),'site_settings'=>table_exists('site_settings')];
}catch(Throwable $e){$result['ok']=false;$result['error']=$e->getMessage();http_response_code(500);}
echo json_encode($result,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);