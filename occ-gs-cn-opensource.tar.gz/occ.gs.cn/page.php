<?php
/* v6.1.6.59 自定义页面渲染器 — 后台「页面」模块的前台出口
   访问方式：page.php?slug=about  （伪静态可映射 /about）*/
require __DIR__.'/api/config.php';
require __DIR__.'/api/bootstrap.php';

function pg_e($s){return htmlspecialchars((string)$s,ENT_QUOTES,'UTF-8');}
function pg_404($msg='页面不存在或尚未发布'){
    http_response_code(404);
    $t='页面不存在';
    echo '<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
        .'<title>'.pg_e($t).'</title><meta name="robots" content="noindex"><link rel="stylesheet" href="assets/page.css?v=6.1.6.69"><link rel="stylesheet" href="assets/archive-ui.css?v=7.2.0"></head>'
        .'<body><main class="pg-wrap"><div class="pg-empty"><b>'.pg_e($msg).'</b><a href="./">返回地图</a></div></main></body></html>';
    exit;
}

$slug=strtolower(trim((string)($_GET['slug']??'')));
$slug=preg_replace('/[^a-z0-9-]/','',$slug);
if($slug==='')pg_404('未指定页面别名');

$settings=[];$page=null;
try{
    db();migrate_schema();
    $settings=all_settings();
    if(!table_exists('custom_pages'))pg_404('自定义页面功能尚未初始化');
    $s=db()->prepare('SELECT * FROM custom_pages WHERE slug=? AND status=1 AND published_at IS NOT NULL AND published_at<=NOW() LIMIT 1');
    $s->execute([$slug]);
    $page=$s->fetch();
    if(!$page)pg_404();
    try{db()->prepare('UPDATE custom_pages SET views=views+1 WHERE id=?')->execute([$page['id']]);}catch(Throwable $e){}
}catch(Throwable $e){pg_404('页面暂时无法读取');}

$siteName=str_replace('诡述生态','',trim((string)($settings['site_name']??'')))?:'全球灵异地点地图';
$page['title']=str_replace('诡述生态','',(string)($page['title']??''));$page['summary']=str_replace('诡述生态','',(string)($page['summary']??''));$page['content']=str_replace('诡述生态','',(string)($page['content']??''));$page['seo_title']=str_replace('诡述生态','',(string)($page['seo_title']??''));$page['seo_description']=str_replace('诡述生态','',(string)($page['seo_description']??''));
$title=trim((string)($page['seo_title']??''))!==''?$page['seo_title']:($page['title'].' - '.$siteName);
$desc=trim((string)($page['seo_description']??''))!==''?$page['seo_description']:(string)$page['summary'];
$kw=str_replace('诡述生态','',(string)($page['seo_keywords']??''));
$cover=(string)($page['cover_url']??'');
$tpl=($page['template']??'archive')==='plain'?'plain':'archive';
$watermark=str_replace('诡述生态','',trim((string)($settings['watermark']??'')))?:'Ghost Map';
$copyright=str_replace('诡述生态','',(string)($settings['copyright_text']??''));
$icp=str_replace('诡述生态','',(string)($settings['footer_icp_html']??''));

/* 菜单：站点头部菜单 + 勾选了「显示在菜单」的其他页面 */
$menu=[];
foreach(preg_split('/\r?\n/',(string)($settings['header_menu']??'')) as $line){
    $line=trim($line);if($line==='')continue;
    $p=explode('|',$line,2);$n=trim($p[0]);$u=trim($p[1]??'');
    if($n!==''&&$u!=='' && strpos($u,'#')!==0)$menu[]=['name'=>$n,'url'=>$u];
}
try{
    foreach(db()->query("SELECT slug,title FROM custom_pages WHERE status=1 AND show_in_menu=1 AND published_at IS NOT NULL AND published_at<=NOW() ORDER BY sort_order,id")->fetchAll() as $m)
        $menu[]=['name'=>$m['title'],'url'=>'page.php?slug='.$m['slug'],'active'=>$m['slug']===$slug];
}catch(Throwable $e){}
?><!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?php echo pg_e($title);?></title>
<?php if($desc!==''){?><meta name="description" content="<?php echo pg_e($desc);?>"><?php }?>
<?php if($kw!==''){?><meta name="keywords" content="<?php echo pg_e($kw);?>"><?php }?>
<meta property="og:type" content="article">
<meta property="og:title" content="<?php echo pg_e($page['title']);?>">
<?php if($desc!==''){?><meta property="og:description" content="<?php echo pg_e($desc);?>"><?php }?>
<?php if($cover!==''){?><meta property="og:image" content="<?php echo pg_e($cover);?>"><?php }?>
<link rel="icon" href="assets/site-logo.webp?v=6.1.7.64" type="image/webp">
<link rel="stylesheet" href="assets/page.css?v=6.1.6.69">
<link rel="stylesheet" href="assets/v61688-fix.css?v=6.1.6.88">
</head>
<body class="pg-tpl-<?php echo pg_e($tpl);?>">
<main class="pg-wrap">
  <header class="pg-head">
    <div class="pg-brand"><a href="./"><?php echo pg_e($siteName);?></a></div>
    <?php if($menu){?><nav class="pg-nav"><?php foreach($menu as $m){?><a href="<?php echo pg_e($m['url']);?>"<?php echo !empty($m['active'])?' class="active"':'';?>><?php echo pg_e($m['name']);?></a><?php }?></nav><?php }?>
  </header>

  <article class="pg-article">
    <div class="pg-mark">页面档案</div>
    <h1><?php echo pg_e($page['title']);?></h1>
    <div class="pg-meta">
      <?php if(!empty($page['published_at'])){?><time datetime="<?php echo pg_e($page['published_at']);?>"><?php echo pg_e(substr((string)$page['published_at'],0,10));?></time><?php }?>
      <span><?php echo (int)$page['views'];?> 次阅读</span>
    </div>
    <?php if(trim((string)($page['summary']??''))!==''){?><p class="pg-summary"><?php echo pg_e($page['summary']);?></p><?php }?>
    <?php if($cover!==''){?><img class="pg-cover" src="<?php echo pg_e($cover);?>" alt="<?php echo pg_e($page['title']);?>" loading="lazy"><?php }?>
    <div class="pg-body"><?php echo (string)($page['content']??'');?></div>
  </article>

  <footer class="pg-foot">
    <a class="pg-back" href="./">返回地图</a>
    <div class="pg-foot-txt">
      <span><?php echo pg_e($watermark);?></span>
      <?php if($copyright!==''){?><span><?php echo pg_e($copyright);?></span><?php }?>
      <?php if($icp!==''){?><span><?php echo $icp;?></span><?php }?>
    </div>
  </footer>
</main>
<script src="external-config.php?v=6.1.7.46"></script><script src="assets/external-redirect.js?v=6.1.7.63"></script>

<!-- TG-CREDIT:v1 版权归中国灵异网所有 https://talkghost.com 请勿删除 -->
<script src="assets/credit-guard.js?v=1.0.0"></script>
</body>
</html>
