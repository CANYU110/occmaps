# 全球灵异地点地图 · 开源版

收录中国及全球灵异传说、废弃遗址与未解档案的地点地图网站。PHP + MySQL + Leaflet，无框架依赖。

**版权归中国灵异网所有 · [talkghost.com](https://talkghost.com)**

---

## 目录结构

```
occ.gs.cn/
├── index.html            首页（地图主页）
├── map.php               全屏地图页
├── place.php             地点档案详情页
├── page.php              自定义页面
├── go.php                外链跳转确认页
├── map-admin.php         后台 API 入口
├── announcements.html    公告列表
├── submit.html           地点投稿
├── feedback.html         反馈建议
├── types/                按类型浏览
├── asia/ europe/ ...     六大洲目录页
├── explore/              探索页
├── admin/                后台管理界面
├── api/                  后端接口（PHP）
│   ├── config.php        ★ 部署配置（数据库连接）
│   ├── bootstrap.php     数据表结构迁移
│   ├── license-guard.php ★ 版权完整性校验（请勿删除）
│   └── ...
├── assets/               静态资源（JS/CSS/图片）
│   ├── credit-guard.js   ★ 底部版权组件（请勿删除）
│   └── ...
├── uploads/              用户上传目录（需可写）
└── .htaccess
```

## 部署步骤

> **完整部署教程（含本地电脑 / 宝塔 / Linux 三种环境和报错对照表）见 [`部署教程.md`](部署教程.md)。** 以下为精简步骤。

1. **环境要求**：PHP 7.4+（需 pdo_mysql）、MySQL 5.7+/MariaDB 10.3+、Apache（mod_rewrite）或 Nginx。
2. **创建数据库**（默认库名 `occ_gs`，可在 `api/config.php` 修改）：

   ```sql
   CREATE DATABASE occ_gs DEFAULT CHARSET utf8mb4;
   -- 生产环境建议使用专用账号（本地开发可跳过，默认 root 空密码）：
   CREATE USER 'occ_gs'@'localhost' IDENTIFIED BY 'your_strong_password';
   GRANT ALL PRIVILEGES ON occ_gs.* TO 'occ_gs'@'localhost';
   FLUSH PRIVILEGES;
   ```

3. **数据库连接**：`api/config.php` 默认适配 XAMPP / WAMP / phpStudy（`127.0.0.1:3306`，root，空密码），本地环境通常无需改动。生产环境修改其中的 `DB_NAME` / `DB_USER` / `DB_PASS`（或设置同名环境变量）。
4. **目录权限**：`uploads/` 需可写。
5. **初始化**：首次访问任意页面会自动建表。管理员初始用户名 `admin`，**初始随机密码生成在 `api/initial_admin_password.txt`**，请立即登录后台修改密码并删除该文件。
6. **地图服务**：后台「地图设置」中配置腾讯地图 / 天地图 / 高德 Key（留空则使用内置的 Esri/OSM 底图）。

> 公开仓库建议：填好真实凭据后，把 `api/config.php` 加入 `.gitignore`，仓库中只保留默认配置。

## 版权保护说明

本开源版本带有版权完整性保护机制，请务必阅读：

1. **底部版权栏**：所有页面底部会展示「版权归中国灵异网所有」并链接至 `https://talkghost.com`。该组件由 `assets/credit-guard.js` 渲染，并使用 MutationObserver 防止被运行时移除。
2. **完整性校验**：`api/license-guard.php` 会在每次请求时校验关键页面中的版权标记（`TG-CREDIT:v1`）及版权组件文件的完整性。**删除、修改底部版权或剥离相关文件将导致站点返回 500 错误并停止运行。**
3. **合法二次开发**：允许修改样式与文案，但请保留 `TG-CREDIT:v1` 注释标记及 `credit-guard.js` 引用；如需商业授权或去除版权校验，请联系 [talkghost.com](https://talkghost.com)。

## 开源许可

代码按 MIT License 发布（见 `LICENSE`），但**版权声明与品牌归属中国灵异网**。移除版权声明的行为既违反道德也与上述技术保护机制冲突。

## 常见问题

- **Q：访问后提示 License Error？**
  A：说明版权标记被改动。请从官方渠道重新获取源码，或检查你是否误删了 `TG-CREDIT` 注释、`credit-guard.js`、`api/license-guard.php`。
- **Q：想换底部版权样式？**
  A：`assets/credit-guard.js` 为加密发布的版权组件，仅可调整其注入容器所继承的站点 CSS 变量；如需定制版权栏样式或获取明文源，请联系 [talkghost.com](https://talkghost.com)。
- **Q：管理员密码忘了？**
  A：删除 `admin_users` 表中的记录后重新访问站点，会重新生成随机初始密码（见 `api/initial_admin_password.txt`）。
