<?php
require __DIR__.'/api/points.php';
