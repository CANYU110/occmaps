<?php
$id=isset($_GET['id'])?(int)$_GET['id']:0;
?><!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>地点地图 · 全球灵异地点地图</title><link rel="icon" href="assets/site-logo.webp?v=6.1.7.64" type="image/webp" sizes="any">
<link rel="stylesheet" href="assets/leaflet/leaflet.css?v=1.9.4">
<link rel="stylesheet" href="assets/map-only.css?v=6.1.7.94">
<link rel="stylesheet" href="assets/archive-ui.css?v=7.2.0"></head>
<body class="map-only-page" data-place-id="<?= $id ?>">
<div id="mapOnly"></div>
<div class="map-only-tools"><a class="map-only-back" id="mapOnlyBack" href="place.php?id=<?= $id ?>">返回介绍</a><label>底图<select id="mapOnlyBase"><option value="tianditu">天地图标准</option><option value="tencent" hidden>腾讯标准</option><option value="amap">高德标准</option><option value="satellite">高德卫星</option><option value="osmglobal">Esri 国际街道</option><option value="osm">OSM 全球</option><option value="dark">暗色地图</option></select></label></div>
<div id="mapOnlyAttribution" class="map-provider-watermark">OpenStreetMap</div><div class="map-only-watermark">Ghost Map</div>
<div id="mapOnlyNotice" class="map-only-notice">正在读取地点坐标……</div>
<script src="assets/leaflet/leaflet.js?v=1.9.4"></script><script src="assets/coordtransform.js?v=6.1.7.95"></script><script src="assets/map-only.js?v=6.1.7.95"></script><script src="external-config.php?v=6.1.7.46"></script><script src="assets/external-redirect.js?v=6.1.7.63"></script>

<!-- TG-CREDIT:v1 版权归中国灵异网所有 https://talkghost.com 请勿删除 -->
<script src="assets/credit-guard.js?v=1.0.0"></script>
</body>
</html>
