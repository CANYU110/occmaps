<?php
// 安全健康检查：不输出主机、账号、密码、Key 或 SQL 错误详情。
require __DIR__.'/config.php';
$result=['php'=>PHP_VERSION,'pdo_mysql'=>extension_loaded('pdo_mysql'),'database'=>false,'places_table'=>false,'places_count'=>0,'extended_schema'=>false,'writable_uploads'=>false];
try{
 $pdo=db();$result['database']=true;$tables=$pdo->query('SHOW TABLES')->fetchAll(PDO::FETCH_COLUMN);$result['places_table']=in_array('spooky_places',$tables,true);
 if($result['places_table']){$result['places_count']=(int)$pdo->query('SELECT COUNT(*) FROM spooky_places')->fetchColumn();$cols=$pdo->query('SHOW COLUMNS FROM spooky_places')->fetchAll(PDO::FETCH_COLUMN);$result['extended_schema']=in_array('province',$cols,true)&&in_array('status',$cols,true);}
 $uploads=dirname(__DIR__).'/uploads';$result['writable_uploads']=is_dir($uploads)&&is_writable($uploads);
 out($result);
}catch(Throwable $e){out($result);}
