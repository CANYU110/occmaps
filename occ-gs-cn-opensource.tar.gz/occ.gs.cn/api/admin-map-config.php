<?php
require __DIR__.'/config.php';
require __DIR__.'/bootstrap.php';
require_admin();

$settings = all_settings();
header('Content-Type: application/json; charset=utf-8');
echo json_encode([
    'code' => 0,
    'data' => [
        'tencent_enabled' => trim((string)($settings['tencent_maps_enabled'] ?? '0')) === '1' && trim((string)($settings['tencent_maps_key'] ?? '')) !== '',
        'tianditu_enabled' => trim((string)($settings['tianditu_enabled'] ?? '0')) === '1' && trim((string)($settings['tianditu_token'] ?? '')) !== '',
    ],
], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
