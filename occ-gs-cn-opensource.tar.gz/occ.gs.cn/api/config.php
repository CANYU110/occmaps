<?php
// ============================================================
// 全球灵异地点地图 · 默认配置（开源版）
// ------------------------------------------------------------
// 默认值为常见本地集成环境（XAMPP / WAMP / phpStudy）的开箱配置：
//   · 地址 127.0.0.1:3306，用户 root，密码为空
//   · phpStudy 部分版本 root 密码为 root，按实际改 DB_PASS 即可
//   · 数据库 occ_gs 首次访问时不会自动创建，请先建库（见 README.md）
//
// 生产环境请修改为专用数据库账号，并不要把真实密码提交到公开仓库。
// 支持环境变量覆盖（优先级高于下方默认值）：
//   DB_HOST / DB_PORT / DB_NAME / DB_USER / DB_PASS / AMAP_KEY
// ============================================================
define('DB_HOST', getenv('DB_HOST') ?: '127.0.0.1');
define('DB_PORT', getenv('DB_PORT') ?: '3306');
define('DB_NAME', getenv('DB_NAME') ?: 'occ_gs');
define('DB_USER', getenv('DB_USER') ?: 'root');
define('DB_PASS', getenv('DB_PASS') ?: '');
// 高德开放平台「Web服务」Key（可选）。留空时在后台「地图设置」中配置即可。
// 请勿把真实 Key 提交到公开仓库。
define('AMAP_KEY', getenv('AMAP_KEY') ?: '');

// 版权保护模块（请勿删除，详见 README.md「版权保护说明」）
require_once __DIR__.'/license-guard.php';

if (session_status() !== PHP_SESSION_ACTIVE) { session_name('global_paranormal_admin'); $remember=($_POST['remember']??'')==='1'||isset($_COOKIE['global_paranormal_remember']); session_set_cookie_params(['lifetime'=>$remember?2592000:0,'path'=>'/','secure'=>!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off','httponly'=>true,'samesite'=>'Lax']); session_start(); }
function db() {
    static $pdo = null;
    if ($pdo === null) {
        $dsn = 'mysql:host='.DB_HOST.';port='.DB_PORT.';dbname='.DB_NAME.';charset=utf8mb4';
        $pdo = new PDO($dsn, DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false
        ]);
    }
    return $pdo;
}
function remove_legacy_brand($value) {
    if (is_string($value)) return str_replace('诡述生态', '', $value);
    if (is_array($value)) { foreach ($value as $k=>$v) $value[$k]=remove_legacy_brand($v); return $value; }
    return $value;
}
function out($data, $code=0) {
    if (ob_get_level()) { ob_clean(); }
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    echo json_encode(['code'=>$code, 'data'=>remove_legacy_brand($data)], JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES); exit;
}
function fail($msg, $http=400) {
    if (ob_get_level()) { ob_clean(); }
    http_response_code($http);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    header('Pragma: no-cache');
    echo json_encode(['code'=>1, 'msg'=>$msg], JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES); exit;
}
function require_admin(){ if(empty($_SESSION['admin'])) fail('登录已过期',401); }
