<?php
// 公开只读接口：绝不建表、不改表，兼容旧版 spooky_places 结构。
require __DIR__.'/config.php';require __DIR__.'/bootstrap.php';
// 首屏公共接口只读取已部署的数据；建表和历史迁移仅由后台/维护入口执行，避免每次访问都触发多轮 information_schema 查询和 ALTER TABLE。
try{
 $pdo=db();
 $tables=$pdo->query('SHOW TABLES')->fetchAll(PDO::FETCH_COLUMN);
 if(!in_array('spooky_places',$tables,true)){
  /* 全新安装首屏加载时，本接口可能早于建表接口执行：缺表时补跑一次迁移再重试（健康站点不会走到这里）。 */
  if(function_exists('migrate_schema')){migrate_schema();$tables=$pdo->query('SHOW TABLES')->fetchAll(PDO::FETCH_COLUMN);}
  if(!in_array('spooky_places',$tables,true)) fail('数据库缺少 spooky_places 表',500);
 }
    $columns=$pdo->query('SHOW COLUMNS FROM spooky_places')->fetchAll(PDO::FETCH_COLUMN);
    $required=['id','title','country','lat','lng','level','category','description','images','created_at'];
    foreach($required as $c){if(!in_array($c,$columns,true)) fail('地点表缺少必要字段：'.$c,500);}
    $optional=['province','city','district','authenticity','content_html','intro_text','history_text','nearby_text','reference_source','recommend_score','image_url','place_media','external_url','views','updated_at','status'];
    $select=$required;
    foreach($optional as $c)if(in_array($c,$columns,true))$select[]=$c;
    $idParam=isset($_GET['id'])?(int)$_GET['id']:0;
    $detail=$idParam>0;
    if(!$detail){
        // 首屏仅返回地图定位、筛选和搜索所需字段，图片与长正文点击地点后读取。
        $light=['id','title','country','lat','lng','level','category','province','city','district','authenticity','recommend_score','image_url','description','status'];
        $select=array_values(array_filter($light,function($c)use($columns){return in_array($c,$columns,true);}));
    }
    $where=in_array('status',$columns,true)?' WHERE status=1':'';
    if($detail)$where.=($where?' AND ':' WHERE ').' id='.$idParam;
    $sql='SELECT `'.implode('`,`',$select).'` FROM spooky_places'.$where.($detail?' LIMIT 1':' ORDER BY level DESC,id DESC');
    $places=$pdo->query($sql)->fetchAll();
    foreach($places as &$place)foreach($place as $key=>$value)if(is_string($value))$place[$key]=str_replace('诡述生态','',$value);unset($place);
    if($detail){foreach($places as &$p){foreach($optional as $c)if(!array_key_exists($c,$p))$p[$c]=in_array($c,['recommend_score'],true)?'4.5':'';}unset($p);}

    $cats=[];
    if(in_array('categories',$tables,true)){
        try{$cats=$pdo->query('SELECT id,name,slug,description,color,icon,icon_url,sort_order FROM categories WHERE status=1 ORDER BY sort_order,id')->fetchAll();foreach($cats as &$cat)$cat['name']=str_replace('诡述生态','',(string)($cat['name']??''));unset($cat);}catch(Throwable $e){$cats=[];}
    }
    if(!$cats){$names=['village'=>['鬼村','#a8503a'],'abandoned'=>['废弃之地','#7a6a52'],'forest'=>['诡秘森林','#4f6b4a'],'mansion'=>['灵异宅邸','#8a5a44'],'hospital'=>['医院','#9aa8a4'],'school'=>['校园','#6b6355'],'island'=>['孤岛','#4a6b5e'],'castle'=>['古堡','#6b5b7b'],'hotel'=>['旅馆','#b58a4a'],'cave'=>['洞穴','#6e7068'],'other'=>['其他','#8d8b7e']];$i=0;foreach($names as $slug=>$row)$cats[]=['id'=>++$i,'name'=>$row[0],'slug'=>$slug,'description'=>'','color'=>$row[1],'icon'=>'✦','icon_url'=>'','sort_order'=>$i*10];}
    $settings=[];
    if(in_array('site_settings',$tables,true)){
        try{foreach($pdo->query('SELECT setting_key,setting_value FROM site_settings')->fetchAll() as $r)$settings[$r['setting_key']]=$r['setting_value'];}catch(Throwable $e){}
    }
    $tencentConfigured=trim((string)($settings['tencent_maps_key']??''))!=='';
$tiandituConfigured=trim((string)($settings['tianditu_token']??''))!=='';
unset($settings['map_service_key'],$settings['tencent_maps_key'],$settings['tianditu_token']);
$settings['tencent_maps_configured']=$tencentConfigured?'1':'0';
$settings['tianditu_token_configured']=$tiandituConfigured?'1':'0';
    foreach($settings as $key=>$value)$settings[$key]=str_replace('诡述生态','',(string)$value);
    $settings['site_name']=$settings['site_name']??'全球灵异地点地图';
    $settings+=['site_name'=>'全球灵异地点地图','site_subtitle'=>'GLOBAL PARANORMAL ARCHIVE','seo_title'=>'全球灵异地点地图—持续跟进中','seo_description'=>'全球灵异地点地图，收录全球灵异传说与地点档案','seo_keywords'=>'灵异地点,灵异地图,全球灵异地点地图','header_menu'=>"地图|#map\n公告|announcements.html",'mobile_nav'=>"地图|#map\n公告|announcements.html",'welcome_title'=>'欢迎进入全球灵异地点地图','welcome_text'=>'收录中国及全球各地的灵异传说、废弃遗址与未解档案。','welcome_subtitle'=>'GLOBAL PARANORMAL ARCHIVE','welcome_button_text'=>'开启地图档案','welcome_start_at'=>'','welcome_end_at'=>'','welcome_delay'=>'0','welcome_overlay_color'=>'#060806','welcome_bg_color'=>'#ddd3bd','welcome_title_color'=>'#1a1b18','welcome_text_color'=>'#53544e','welcome_accent_color'=>'#8e3d28','welcome_button_color'=>'#8f432e','welcome_button_text_color'=>'#f7ecd8','loading_preset'=>'archive','loading_icon'=>'✦','loading_title'=>'档案启封','loading_text'=>'正在读取异闻档案','footer_icp_html'=>'','footer_logo_url'=>'assets/footer-default-logo.svg','footer_bg_image'=>'','footer_enabled'=>'1','footer_brand_title'=>'全球灵异地点地图','footer_brand_intro'=>'收录民间传说、地方志、都市怪谈与实地探访记录，持续整理值得考据的异闻地点档案。','footer_explore_title'=>'探索','footer_explore_links'=>"地图首页|#map\n地点投稿|submit.html\n反馈建议|feedback.html\n公告档案|announcements.html",'footer_category_title'=>'类别','footer_category_mode'=>'auto','footer_category_links'=>'','footer_site_title'=>'关于本站','footer_site_links'=>"关于本站|page.php?slug=about\n联系方式|page.php?slug=contact\n隐私政策|page.php?slug=privacy\n用户条款|page.php?slug=terms",'footer_bottom_links'=>"地点投稿|submit.html\n公告|announcements.html\n关于|page.php?slug=about\n隐私|page.php?slug=privacy",'footer_heading_color'=>'#b8813f','footer_link_color'=>'#8b8878','footer_bg_color'=>'#12140f','footer_divider_color'=>'#31352c','accent_color'=>'#b8813f','default_map'=>'amap','map_theme'=>'whitesmoke','map_enabled'=>'1','map_center_lat'=>'27.0000','map_center_lng'=>'105.0000','map_zoom'=>'3','map_js_key'=>'','marker_default_color'=>'#b8813f','marker_link_color'=>'#6f8a52','marker_plain_color'=>'#7a7466','detail_button_color'=>'#b8813f','truth_color_true'=>'#6f8a52','truth_color_false'=>'#8d8b7e','truth_color_unknown'=>'#b8813f','truth_color_doubt'=>'#8a5a6b','flat_view_icon'=>'▦','flat_view_name'=>'平面地图','globe_view_icon'=>'◍','globe_view_name'=>'地球仪','widget_nearby_title'=>'周边灵异地','widget_category_title'=>'档案类型构成','widget_levels_title'=>'危险等级分布','widget_regions_title'=>'高频异闻地区','widget_density_title'=>'档案密度图','widget_viewport_title'=>'地图范围内收录','show_metrics'=>'1','show_welcome'=>'1','copyright_text'=>'© '.date('Y').' 版权所有','icp_number'=>'','icp_url'=>'https://beian.miit.gov.cn/','custom_css'=>'','ad_enabled'=>'1','ad_type'=>'text','ad_title'=>'全球异闻档案','ad_text'=>'广告位招租 · 点击查看详情','ad_image'=>'','ad_link'=>'https://occ.gs.cn/','ad_start_at'=>'','ad_end_at'=>''];
    $ads=[];if(in_array('ad_slots',$tables,true)){try{$ads=$pdo->query("SELECT id,title,ad_text,ad_type,image_url,link_url,start_at,end_at,sort_order,display_scope FROM ad_slots WHERE status=1 AND (start_at IS NULL OR start_at<=NOW()) AND (end_at IS NULL OR end_at>=NOW()) ORDER BY sort_order,id DESC LIMIT 20")->fetchAll();}catch(Throwable $e){$ads=[];}}
    foreach($ads as &$ad){$ad['title']=str_replace('诡述生态','',(string)($ad['title']??''));$ad['ad_text']=str_replace('诡述生态','',(string)($ad['ad_text']??''));}unset($ad);
    if(!$ads&&($settings['ad_enabled']??'1')!=='0')$ads[]=['id'=>0,'title'=>$settings['ad_title']??'全球异闻档案','ad_text'=>$settings['ad_text']??'广告位招租','ad_type'=>$settings['ad_type']??'text','image_url'=>$settings['ad_image']??'','link_url'=>$settings['ad_link']??'','start_at'=>$settings['ad_start_at']??null,'end_at'=>$settings['ad_end_at']??null,'sort_order'=>0];
    $countries=[];$provinces=[];$cities=[];$districts=[];$catCounts=[];
    foreach($places as $p){
        $country=trim((string)$p['country'])?:'未知地区';
        $province=trim((string)($p['province']??''));
        $city=trim((string)($p['city']??''));
        $district=trim((string)($p['district']??''));
        $countries[$country]=($countries[$country]??0)+1;
        if($province)$provinces[$country][$province]=($provinces[$country][$province]??0)+1;
        if($city)$cities[$country][$province?:'未填写省份'][$city]=($cities[$country][$province?:'未填写省份'][$city]??0)+1;
        if($district)$districts[$country][$province?:'未填写省份'][$city?:'未填写城市'][$district]=($districts[$country][$province?:'未填写省份'][$city?:'未填写城市'][$district]??0)+1;
        $cat=$p['category']?:'other';$catCounts[$cat]=($catCounts[$cat]??0)+1;
    }
    arsort($countries);
    foreach($provinces as &$rows)arsort($rows);unset($rows);
    foreach($cities as &$byProvince)foreach($byProvince as &$rows)arsort($rows);unset($byProvince,$rows);
    foreach($districts as &$byProvince)foreach($byProvince as &$byCity)foreach($byCity as &$rows)arsort($rows);unset($byProvince,$byCity,$rows);
    if($detail){
        if(!$places)fail('地点不存在或已下线',404);
        out(['place'=>$places[0],'categories'=>$cats,'settings'=>$settings]);
    }
    out(['places'=>$places,'categories'=>$cats,'ads'=>$ads,'settings'=>$settings,'filters'=>['countries'=>$countries,'provinces'=>$provinces,'cities'=>$cities,'districts'=>$districts],'charts'=>['categories'=>$catCounts],'schema'=>['extended'=>in_array('province',$columns,true),'district'=>in_array('district',$columns,true)]]);
}catch(Throwable $e){fail('只读数据接口失败：'.$e->getMessage(),500);}
