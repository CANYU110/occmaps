<?php
// Public media upload endpoint. It intentionally does not load the database or schema migration.
ini_set('display_errors','0');
header('X-Content-Type-Options: nosniff');
function media_fail($msg,$code=422){http_response_code($code);header('Content-Type: application/json; charset=utf-8');echo json_encode(['code'=>$code,'msg'=>$msg,'data'=>null],JSON_UNESCAPED_UNICODE);exit;}
if($_SERVER['REQUEST_METHOD']!=='POST'||empty($_FILES['file']))media_fail('请选择图片');
$f=$_FILES['file'];if($f['error']!==UPLOAD_ERR_OK)media_fail('上传失败，请检查文件大小');
$mime='';if(class_exists('finfo'))$mime=(new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']);
$ext=strtolower(pathinfo((string)$f['name'],PATHINFO_EXTENSION));
$imageMime=['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp','image/gif'=>'gif'];
if(!isset($imageMime[$mime])&&isset(['jpg'=>'image/jpeg','jpeg'=>'image/jpeg','png'=>'image/png','webp'=>'image/webp','gif'=>'image/gif'][$ext]))$mime=['jpg'=>'image/jpeg','jpeg'=>'image/jpeg','png'=>'image/png','webp'=>'image/webp','gif'=>'image/gif'][$ext];
if(!isset($imageMime[$mime]))media_fail('只支持 JPG、PNG、WebP、GIF 图片');
$storedExt=$imageMime[$mime];$isVideo=false;
$max=8*1024*1024;if((int)$f['size']>$max)media_fail('图片不能超过8MB');
$month=date('Ym');$dir=__DIR__.'/../uploads/'.$month;if(!is_dir($dir)&&!mkdir($dir,0755,true))media_fail('无法创建上传目录',500);
$name=date('YmdHis').'-'.bin2hex(random_bytes(6)).'.'.$storedExt;$target=$dir.'/'.$name;if(!move_uploaded_file($f['tmp_name'],$target))media_fail('保存媒体失败',500);if(!is_file($target)||filesize($target)!==(int)$f['size'])media_fail('媒体落盘校验失败',500);
header('Content-Type: application/json; charset=utf-8');echo json_encode(['code'=>0,'msg'=>'ok','data'=>['url'=>'uploads/'.$month.'/'.$name,'media_type'=>$isVideo?'video':'image','mime'=>$mime,'size'=>(int)$f['size']]],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
