<?php
// Stream uploaded videos with a correct MIME type and HTTP Range support.
ini_set('display_errors','0');
error_reporting(0);
$relative=str_replace('\\','/',trim((string)($_GET['file']??'')));
while(strpos($relative,'../')===0)$relative=substr($relative,3);
if(!preg_match('#^uploads/[A-Za-z0-9_./-]+\.(mp4|webm|ogv|ogg|mov|mkv|avi)$#i',$relative)){http_response_code(400);exit('Invalid media path');}
$root=realpath(__DIR__.'/../uploads');$file=realpath(__DIR__.'/../'.$relative);
if(!$root||!$file||strpos(strtolower($file),strtolower($root.DIRECTORY_SEPARATOR))!==0||!is_file($file)){http_response_code(404);exit('Media not found');}
$ext=strtolower(pathinfo($file,PATHINFO_EXTENSION));$mime=['mp4'=>'video/mp4','webm'=>'video/webm','ogv'=>'video/ogg','ogg'=>'video/ogg','mov'=>'video/quicktime','mkv'=>'video/x-matroska','avi'=>'video/x-msvideo'][$ext]??'application/octet-stream';
$size=filesize($file);$start=0;$end=$size-1;$range=$_SERVER['HTTP_RANGE']??'';
if($range&&preg_match('/bytes=(\d*)-(\d*)/',$range,$m)){
  if($m[1]===''&&$m[2]===''){$start=0;$end=$size-1;}elseif($m[1]===''){$length=(int)$m[2];$start=max(0,$size-$length);}else{$start=(int)$m[1];if($m[2]!=='')$end=(int)$m[2];}
  if($start>$end||$start<0||$start>=$size){http_response_code(416);header('Content-Range: bytes */'.$size);exit;}
  $end=min($end,$size-1);http_response_code(206);
}
$length=$end-$start+1;header('Content-Type: '.$mime);header('Content-Length: '.$length);header('Accept-Ranges: bytes');header('Cache-Control: public, max-age=86400');header('X-Content-Type-Options: nosniff');if($range)header('Content-Range: bytes '.$start.'-'.$end.'/'.$size);
$fp=fopen($file,'rb');fseek($fp,$start);$remaining=$length;while($remaining>0&&!feof($fp)){$chunk=fread($fp,min(1048576,$remaining));if($chunk===false||$chunk==='')break;echo $chunk;$remaining-=strlen($chunk);if(function_exists('ob_flush'))@ob_flush();flush();}fclose($fp);
