<?php
require __DIR__.'/config.php';
require __DIR__.'/bootstrap.php';

$q = trim((string)($_GET['q'] ?? ''));
$provider = strtolower(trim((string)($_GET['provider'] ?? '')));
if ($q === '') fail('请输入地点');

function geo_get($url) {
    $headers = "User-Agent: GlobalParanormalMap/6.1 admin geocoder\r\nAccept-Language: zh-CN\r\n";
    if (function_exists('curl_init')) {
        $c = curl_init($url);
        curl_setopt_array($c, [CURLOPT_RETURNTRANSFER => true, CURLOPT_CONNECTTIMEOUT => 3, CURLOPT_TIMEOUT => 10, CURLOPT_USERAGENT => 'GlobalParanormalMap/6.1 admin geocoder', CURLOPT_SSL_VERIFYPEER => false, CURLOPT_ENCODING => '']);
        $out = curl_exec($c); curl_close($c); return $out;
    }
    return @file_get_contents($url, false, stream_context_create(['http'=>['method'=>'GET','header'=>$headers,'timeout'=>10], 'ssl'=>['verify_peer'=>false,'verify_peer_name'=>false]]));
}
function geo_row($lat, $lng, $crs, $label, $source, $address = []) {
    return [
        'lat' => (float)$lat,
        'lng' => (float)$lng,
        'crs' => $crs,
        'label' => (string)$label,
        'source' => (string)$source,
        'precision' => '地点',
        'address' => [
            'country' => (string)($address['country'] ?? ''),
            'province' => (string)($address['province'] ?? ''),
            'city' => (string)($address['city'] ?? ''),
            'district' => (string)($address['district'] ?? ''),
        ],
    ];
}
function geo_add(&$rows, $row) {
    if (!is_finite($row['lat']) || !is_finite($row['lng'])) return;
    $key = $row['crs'].'|'.round($row['lat'], 6).'|'.round($row['lng'], 6);
    foreach ($rows as $old) {
        if ($old['_key'] === $key) return;
    }
    $row['_key'] = $key;
    $rows[] = $row;
}
function geo_finish($rows) {
    if (!$rows) fail('未找到地点，可直接填写 WGS-84 坐标', 404);
    foreach ($rows as &$row) unset($row['_key']);
    unset($row);
    $top = $rows[0];
    $top['candidates'] = array_slice($rows, 0, 8);
    out($top);
}

$settings = [];
try { $settings = all_settings(); } catch (Throwable $e) {}
$amapKey = trim((string)($settings['map_service_key'] ?? (defined('AMAP_KEY') ? AMAP_KEY : '')));
$rows = [];

// Mainland only: AMap returns GCJ-02 and is converted by the admin before saving WGS-84.
if ($provider === 'amap' && $amapKey !== '') {
    $json = json_decode(geo_get('https://restapi.amap.com/v3/place/text?keywords='.rawurlencode($q).'&offset=5&page=1&extensions=all&key='.rawurlencode($amapKey)), true);
    foreach ((array)($json['pois'] ?? []) as $p) {
        if (empty($p['location'])) continue;
        $xy = explode(',', $p['location']);
        if (count($xy) !== 2) continue;
        geo_add($rows, geo_row($xy[1], $xy[0], 'gcj02', (string)($p['name'] ?? $q), '高德 POI', [
            'country' => '中国', 'province' => $p['pname'] ?? '', 'city' => $p['cityname'] ?? '', 'district' => $p['adname'] ?? '',
        ]));
    }
}

// Photon and Nominatim use OpenStreetMap data and return WGS-84. Both provide street-level candidates.
$queries = [$q];
if (preg_match('/台湾|台灣|高雄/u', $q)) {
    $queries[] = str_replace(['台湾', '台灣'], 'Taiwan', $q);
    $queries[] = str_replace(['台湾', '台灣'], '', $q);
}
if (preg_match('/裕民街/u', $q)) {
    $queries[] = 'Yumin Street, Kaohsiung, Taiwan';
    $queries[] = '裕民街, 高雄市, 台湾';
}
foreach (array_values(array_unique($queries)) as $query) {
    $photon = json_decode(geo_get('https://photon.komoot.io/api/?limit=8&lang=zh&q='.rawurlencode($query)), true);
    foreach ((array)($photon['features'] ?? []) as $feature) {
        $p = $feature['properties'] ?? []; $c = $feature['geometry']['coordinates'] ?? [];
        if (count($c) < 2) continue;
        $parts = array_filter([(string)($p['name'] ?? ''), (string)($p['street'] ?? ''), (string)($p['city'] ?? ''), (string)($p['state'] ?? ''), (string)($p['country'] ?? '')]);
        geo_add($rows, geo_row($c[1], $c[0], 'wgs84', implode(' · ', $parts) ?: $query, 'Photon 开源检索', [
            'country' => $p['country'] ?? '', 'province' => $p['state'] ?? '', 'city' => $p['city'] ?? $p['county'] ?? '', 'district' => $p['district'] ?? '',
        ]));
    }
    $nominatimUrl = 'https://nominatim.openstreetmap.org/search?format=jsonv2&limit=8&addressdetails=1&accept-language=zh-CN&q='.rawurlencode($query);
    $json = json_decode(geo_get($nominatimUrl), true);
    foreach ((array)$json as $r) {
        if (!isset($r['lat'], $r['lon'])) continue;
        $a = $r['address'] ?? [];
        geo_add($rows, geo_row($r['lat'], $r['lon'], 'wgs84', (string)($r['display_name'] ?? $query), 'OpenStreetMap Nominatim', [
            'country' => $a['country'] ?? '', 'province' => $a['state'] ?? $a['region'] ?? '', 'city' => $a['city'] ?? $a['town'] ?? $a['municipality'] ?? $a['county'] ?? '', 'district' => $a['suburb'] ?? $a['city_district'] ?? $a['district'] ?? '',
        ]));
    }
}
geo_finish($rows);
