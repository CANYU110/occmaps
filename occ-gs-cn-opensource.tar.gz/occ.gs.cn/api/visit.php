<?php
require __DIR__.'/config.php';require __DIR__.'/bootstrap.php';migrate_schema();
$ip=client_ip();$salt=hash('sha256',DB_NAME.'|visitor');$ipHash=hash('sha256',$salt.$ip);$onlineSession=trim((string)($_SERVER['HTTP_X_VISITOR_SESSION']??''));$action=$_REQUEST['action']??'';
function visitor_device($ua){$device=preg_match('/Mobile|Android|iPhone|iPad/i',$ua)?(preg_match('/iPad|Tablet/i',$ua)?'平板':'手机'):'电脑';$browser=preg_match('/Edg\\//i',$ua)?'Edge':(preg_match('/Chrome\\//i',$ua)?'Chrome':(preg_match('/Firefox\\//i',$ua)?'Firefox':(preg_match('/Safari\\//i',$ua)?'Safari':'其他')));$os=preg_match('/Windows/i',$ua)?'Windows':(preg_match('/Android/i',$ua)?'Android':(preg_match('/iPhone|iPad|iOS/i',$ua)?'iOS':(preg_match('/Mac OS/i',$ua)?'macOS':(preg_match('/Linux/i',$ua)?'Linux':'其他'))));return[$device,$browser,$os];}
function http_json($url){$ctx=stream_context_create(['http'=>['timeout'=>2.8,'ignore_errors'=>true,'header'=>"User-Agent: SpookyArchive/6.1\r\n"],'https'=>['timeout'=>2.8,'ignore_errors'=>true,'header'=>"User-Agent: SpookyArchive/6.1\r\n"]]);$raw=@file_get_contents($url,false,$ctx);$j=$raw?json_decode($raw,true):null;return is_array($j)?$j:null;}
function region_from_headers($base){$map=['HTTP_CF_IPCOUNTRY'=>'country','HTTP_X_APPENGINE_CITY'=>'city','HTTP_CF_REGION'=>'province','HTTP_CF_IPCITY'=>'city','HTTP_X_FORWARDED_CITY'=>'city'];foreach($map as $header=>$key){if(empty($base[$key])&&!empty($_SERVER[$header]))$base[$key]=substr(urldecode((string)$_SERVER[$header]),0,80);}return $base;}
function valid_public_ip($ip){return filter_var($ip,FILTER_VALIDATE_IP,FILTER_FLAG_NO_PRIV_RANGE|FILTER_FLAG_NO_RES_RANGE)!==false;}
function enrich_ip_region($ip,$base){$base=region_from_headers($base);if(!empty($base['city']))return $base;if(!valid_public_ip($ip))return $base;
 if(defined('AMAP_KEY')&&AMAP_KEY){try{$j=http_json('https://restapi.amap.com/v3/ip?key='.rawurlencode(AMAP_KEY).'&ip='.rawurlencode($ip));if(is_array($j)&&($j['status']??'0')==='1'){$base['country']=$base['country']?:'中国';$base['province']=is_string($j['province']??null)?$j['province']:'';$base['city']=is_string($j['city']??null)?$j['city']:'';}}catch(Throwable $e){}}
 if(empty($base['city'])){try{$j=http_json('http://ip-api.com/json/'.rawurlencode($ip).'?lang=zh-CN&fields=status,country,regionName,city');if(is_array($j)&&($j['status']??'fail')==='success'){$base['country']=$base['country']?:substr((string)($j['country']??''),0,80);$base['province']=$base['province']?:substr((string)($j['regionName']??''),0,80);$base['city']=substr((string)($j['city']??''),0,80);}}catch(Throwable $e){}}
 if(empty($base['city'])){try{$j=http_json('https://ipwho.is/'.rawurlencode($ip));if(is_array($j)&&($j['success']??false)){$base['country']=$base['country']?:substr((string)($j['country']??''),0,80);$base['province']=$base['province']?:substr((string)($j['region']??''),0,80);$base['city']=substr((string)($j['city']??''),0,80);}}catch(Throwable $e){}}
 return $base;}
function cached_ip_region($ip,$base){$base=region_from_headers($base);if(!empty($base['city'])||!table_exists('ip_region_cache'))return$base;$s=db()->prepare('SELECT country,province,city FROM ip_region_cache WHERE ip_address=? AND updated_at>=DATE_SUB(NOW(),INTERVAL 30 DAY)');$s->execute([$ip]);$r=$s->fetch();return$r?:$base;}
function queue_region_enrichment($ip,$base){register_shutdown_function(function()use($ip,$base){try{$r=enrich_ip_region($ip,$base);if(empty($r['city']))return;if(table_exists('ip_region_cache'))db()->prepare('INSERT INTO ip_region_cache(ip_address,country,province,city) VALUES(?,?,?,?) ON DUPLICATE KEY UPDATE country=VALUES(country),province=VALUES(province),city=VALUES(city),updated_at=NOW()')->execute([$ip,$r['country']??'',$r['province']??'',$r['city']??'']);if(table_exists('visitor_logs'))db()->prepare("UPDATE visitor_logs SET country=?,province=?,city=? WHERE ip_address=? AND (city='' OR city IS NULL)")->execute([$r['country']??'',$r['province']??'',$r['city']??'',$ip]);}catch(Throwable $e){}});}
function online_no_cache(){header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');header('Pragma: no-cache');header('Expires: 0');header('Surrogate-Control: no-store');header('CDN-Cache-Control: no-store');}
function touch_online($userType){ global $onlineSession,$ip; if(!table_exists('online_visitors')||!preg_match('/^[a-f0-9]{48}$/i',$onlineSession))return false; try{ $s=db()->prepare('INSERT INTO online_visitors(session_id,ip_address,user_type,last_seen) VALUES(?,?,?,NOW()) ON DUPLICATE KEY UPDATE ip_address=VALUES(ip_address),user_type=VALUES(user_type),last_seen=NOW()'); $s->execute([$onlineSession,$ip,$userType]); $pdo=db(); $pdo->exec('DELETE FROM online_visitors WHERE last_seen < DATE_SUB(NOW(), INTERVAL 15 SECOND)'); return true; }catch(Throwable $e){return false;} }
// 授权按当前公网 IP 持久化；IP 变化后查不到记录，前端会重新征求授权。
if($action==='status'){
    if(!table_exists('location_consents'))out(['authorized'=>false]);
    $s=db()->prepare('SELECT latitude,longitude,accuracy,updated_at FROM location_consents WHERE ip_hash=? LIMIT 1');$s->execute([$ipHash]);$r=$s->fetch();
    out($r?['authorized'=>true,'lat'=>$r['latitude'],'lng'=>$r['longitude'],'accuracy'=>$r['accuracy'],'updated_at'=>$r['updated_at']]:['authorized'=>false]);
}
if($action==='get_online'){
    online_no_cache();
    if(!table_exists('online_visitors'))out(['online_visitors'=>0,'online_admins'=>0,'online_total'=>0,'peak_online'=>0]);
    db()->exec('DELETE FROM online_visitors WHERE last_seen < DATE_SUB(NOW(),INTERVAL 15 SECOND)');
    $s=db()->prepare('SELECT COUNT(*) FROM online_visitors WHERE user_type=? AND last_seen>=DATE_SUB(NOW(),INTERVAL 15 SECOND)');
    $s->execute(['visitor']);$visitors=(int)$s->fetchColumn();
    $s->execute(['admin']);$admins=(int)$s->fetchColumn();
    $peak=(int)db()->query('SELECT COALESCE(CAST(setting_value AS UNSIGNED),0) FROM site_settings WHERE setting_key="peak_online"')->fetchColumn();
    out(['online_visitors'=>$visitors,'online_admins'=>$admins,'online_total'=>$visitors+$admins,'peak_online'=>$peak]);
}
if($action==='offline'){
    online_no_cache();
    $sid=trim((string)($_POST['session_id']??''));
    if(preg_match('/^[a-f0-9]{48}$/i',$sid)&&table_exists('online_visitors')){db()->prepare("DELETE FROM online_visitors WHERE session_id=? AND user_type='visitor'")->execute([$sid]);}
    out(['ok'=>true]);
}
if($action==='heartbeat'){
    online_no_cache();
    if(!preg_match('/^[a-f0-9]{48}$/i',$onlineSession))out(['ok'=>false,'reason'=>'invalid_session'],422);
    touch_online('visitor');
    if(!table_exists('online_visitors'))out(['ok'=>true]);
    $s=db()->prepare('SELECT COUNT(*) FROM online_visitors WHERE user_type=? AND last_seen>=DATE_SUB(NOW(),INTERVAL 15 SECOND)');
    $s->execute(['visitor']); $visitors=(int)$s->fetchColumn();
    $s->execute(['admin']); $admins=(int)$s->fetchColumn();
    $total=$visitors+$admins;
    $peak=(int)db()->query('SELECT COALESCE(CAST(setting_value AS UNSIGNED),0) FROM site_settings WHERE setting_key="peak_online"')->fetchColumn();
    $peakAt=(string)db()->query('SELECT COALESCE(setting_value,\'\') FROM site_settings WHERE setting_key="peak_online_at"')->fetchColumn();
    if($total>$peak||($total>0&&$total===$peak&&$peakAt==='')){ try{ $settings=db()->prepare("INSERT INTO site_settings(setting_key,setting_value) VALUES(?,?) ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value)"); $settings->execute(['peak_online',$total]); $settings->execute(['peak_online_at',date('Y-m-d H:i:s')]); }catch(Throwable $e){} $peak=$total; }
    out(['ok'=>true,'online_visitors'=>$visitors,'online_admins'=>$admins,'online_total'=>$total,'peak_online'=>$peak]);
}
// 普通 pageview 仅记录 IP、城市与设备；精确经纬度仍只在用户明确授权定位后保存。
$consent=(int)($_POST['consent']??0);$pageview=$action==='pageview';if(!$pageview&&$consent!==1)out(['saved'=>false,'reason'=>'consent_required']);
$path=substr((string)($_POST['path']??'/'),0,255);$ref=substr((string)($_SERVER['HTTP_REFERER']??''),0,500);$ua=substr((string)($_SERVER['HTTP_USER_AGENT']??''),0,500);$day=date('Y-m-d');$visitor=hash('sha256',$salt.'|'.$ip.'|'.$ua.'|'.$day);$region=cached_ip_region($ip,client_region());if(empty($region['city']))queue_region_enrichment($ip,$region);list($deviceType,$browser,$os)=visitor_device($ua);$lat=$consent===1&&isset($_POST['lat'])?(float)$_POST['lat']:null;$lng=$consent===1&&isset($_POST['lng'])?(float)$_POST['lng']:null;$accuracy=$consent===1&&isset($_POST['accuracy'])?(float)$_POST['accuracy']:null;$country=substr(trim($_POST['country']??$region['country']),0,80);$province=substr(trim($_POST['province']??''),0,80);$city=substr(trim($_POST['city']??''),0,80);
try{
 touch_online('visitor');
 if($consent===1&&table_exists('location_consents')){$q='INSERT INTO location_consents(ip_hash,ip_address,latitude,longitude,accuracy) VALUES(?,?,?,?,?) ON DUPLICATE KEY UPDATE ip_address=VALUES(ip_address),latitude=VALUES(latitude),longitude=VALUES(longitude),accuracy=VALUES(accuracy),updated_at=CURRENT_TIMESTAMP';db()->prepare($q)->execute([$ipHash,$ip,$lat,$lng,$accuracy]);}
 if(table_exists('visitor_logs')){$q='INSERT INTO visitor_logs(visit_date,visitor_hash,path,referer,ua,ip_hash,ip_address,country,province,city,latitude,longitude,accuracy,location_consent,device_type,browser,os) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)';db()->prepare($q)->execute([$day,$visitor,$path,$ref,$ua,$ipHash,$ip,$country,$province,$city,$lat,$lng,$accuracy,$consent===1?1:0,$deviceType,$browser,$os]);}
 out(['saved'=>true,'authorized'=>true]);
}catch(Throwable $e){out(['saved'=>false]);}