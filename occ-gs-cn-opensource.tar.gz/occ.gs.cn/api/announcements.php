<?php
require __DIR__.'/config.php';
require __DIR__.'/bootstrap.php';
try{
    $pdo=db();
    migrate_schema();
    if(!table_exists('announcements'))out([]);
    $rows=$pdo->query("SELECT id,title,summary,content,media_url,media_type,is_popup,popup_days,published_at,updated_at FROM announcements WHERE status=1 AND published_at IS NOT NULL AND published_at<=NOW() ORDER BY sort_order,published_at DESC,id DESC")->fetchAll();
    $now=time();
    foreach($rows as &$r){
        $r['title']=str_replace('诡述生态','',(string)($r['title']??''));
        $r['summary']=str_replace('诡述生态','',(string)($r['summary']??''));
        $r['content']=str_replace('诡述生态','',(string)($r['content']??''));
        $days=max(1,min(365,(int)($r['popup_days']??7)));
        $published=strtotime((string)($r['published_at']??''));
        $r['popup_days']=$days;
        $r['popup_active']=((int)$r['is_popup']===1&&$published!==false&&$now<=$published+$days*86400)?1:0;
    }
    unset($r);
    out($rows);
}catch(Throwable $e){fail('公告接口暂不可用',500);}
