<?php
require __DIR__.'/config.php';
$country=trim($_GET['country']??'');
if($country==='') fail('缺少国家');
$map=['中国'=>'China','日本'=>'Japan','韩国'=>'South Korea','朝鲜'=>'North Korea','美国'=>'United States','英国'=>'United Kingdom','法国'=>'France','德国'=>'Germany','加拿大'=>'Canada','澳大利亚'=>'Australia','新西兰'=>'New Zealand','俄罗斯'=>'Russia','印度'=>'India','泰国'=>'Thailand','越南'=>'Vietnam','新加坡'=>'Singapore','马来西亚'=>'Malaysia','菲律宾'=>'Philippines','印度尼西亚'=>'Indonesia','意大利'=>'Italy','西班牙'=>'Spain','葡萄牙'=>'Portugal','巴西'=>'Brazil','墨西哥'=>'Mexico','南非'=>'South Africa','埃及'=>'Egypt'];
$q=$map[$country]??$country;
$url='https://countriesnow.space/api/v0.1/countries/cities';
if(!function_exists('curl_init')) fail('服务器未启用 PHP cURL',500);
$c=curl_init($url);curl_setopt_array($c,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_POST=>true,CURLOPT_POSTFIELDS=>json_encode(['country'=>$q],JSON_UNESCAPED_UNICODE),CURLOPT_HTTPHEADER=>['Content-Type: application/json'],CURLOPT_CONNECTTIMEOUT=>4,CURLOPT_TIMEOUT=>12]);$raw=curl_exec($c);curl_close($c);
$j=json_decode((string)$raw,true);$rows=[];foreach(($j['data']??[]) as $name){$name=trim((string)$name);if($name!=='')$rows[$name]=($rows[$name]??0)+1;}
out(['country'=>$country,'cities'=>array_keys($rows),'source'=>'countriesnow']);
