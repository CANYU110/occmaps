<?php
// 将固定的省城热力站点通过本站同源输出，避免 HTTPS 页面嵌入 HTTP 被浏览器拦截。
$base='http://64.90.13.187:10026/';
$asset=isset($_GET['asset'])?ltrim((string)$_GET['asset'],'/'):'';
if($asset!==''&&!preg_match('#^assets/[A-Za-z0-9._/\-]+$#',$asset)){http_response_code(400);exit('bad asset');}
$url=$base.$asset;
$ctx=stream_context_create(['http'=>['timeout'=>15,'ignore_errors'=>true,'header'=>"User-Agent: Mozilla/5.0\r\nAccept: */*\r\n"]]);
$data=@file_get_contents($url,false,$ctx);
if($data===false){http_response_code(502);header('Content-Type: text/plain; charset=utf-8');exit('省城热力服务暂时无法连接');}
$status=200;$type=$asset===''?'text/html; charset=utf-8':'application/octet-stream';
foreach($http_response_header??[] as $h){if(preg_match('#HTTP/\S+\s+(\d+)#',$h,$m))$status=(int)$m[1];if(stripos($h,'Content-Type:')===0)$type=trim(substr($h,13));}
http_response_code($status);header('Content-Type: '.$type);header('Cache-Control: public, max-age=300');header("Content-Security-Policy: default-src 'self' data: blob: https:; script-src 'self' 'unsafe-inline' 'unsafe-eval' blob:; style-src 'self' 'unsafe-inline' https:; img-src 'self' data: blob: https:; connect-src 'self' https: wss:; worker-src 'self' blob:; frame-ancestors 'self'");
if($asset===''){
 $data=preg_replace('#(?:\./)?assets/([A-Za-z0-9._\-/]+)#','api/heat-proxy.php?asset=assets/$1',$data);
 // iframe 内相对 api/ 会多一层，因此改成当前脚本相对地址。
 $data=str_replace('api/heat-proxy.php','heat-proxy.php',$data);
}
echo $data;
