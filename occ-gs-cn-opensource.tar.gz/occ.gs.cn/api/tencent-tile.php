<?php
require __DIR__.'/config.php';
require __DIR__.'/bootstrap.php';

$settings = all_settings();
$key = trim((string)($settings['tencent_maps_key'] ?? ''));
$enabled = trim((string)($settings['tencent_maps_enabled'] ?? '0')) === '1';
$z = filter_input(INPUT_GET, 'z', FILTER_VALIDATE_INT, ['options' => ['min_range' => 0, 'max_range' => 19]]);
$x = filter_input(INPUT_GET, 'x', FILTER_VALIDATE_INT, ['options' => ['min_range' => 0]]);
$y = filter_input(INPUT_GET, 'y', FILTER_VALIDATE_INT, ['options' => ['min_range' => 0]]);
if (!$enabled || $z === false || $x === false || $y === false || $x >= (1 << $z) || $y >= (1 << $z)) {
    http_response_code(404);
    exit;
}
$host = (string)($x % 4);
$url = 'https://rt' . $host . '.map.gtimg.com/tile?z=' . $z . '&x=' . $x . '&y=' . $y . '&styleid=0&version=297';
$body = false;
if (function_exists('curl_init')) {
    $curl = curl_init($url);
    curl_setopt_array($curl, [CURLOPT_RETURNTRANSFER => true, CURLOPT_CONNECTTIMEOUT => 3, CURLOPT_TIMEOUT => 10, CURLOPT_SSL_VERIFYPEER => true]);
    $body = curl_exec($curl);
    $type = (string)curl_getinfo($curl, CURLINFO_CONTENT_TYPE);
    $status = (int)curl_getinfo($curl, CURLINFO_RESPONSE_CODE);
    curl_close($curl);
} else {
    $ctx = stream_context_create(['http'=>['timeout'=>10,'header'=>"User-Agent: GlobalParanormalMap/6.1\r\n"],'https'=>['timeout'=>10,'header'=>"User-Agent: GlobalParanormalMap/6.1\r\n"]]);
    $body = @file_get_contents($url, false, $ctx);
    $type = 'image/png';
    $status = $body === false ? 502 : 200;
}
if ($body === false || $status < 200 || $status >= 300) {
    http_response_code(502);
    exit;
}
$head=substr((string)$body,0,12);if(substr($head,0,3)==="\xFF\xD8\xFF")$type='image/jpeg';elseif(substr($head,0,8)==="\x89PNG\r\n\x1a\n")$type='image/png';elseif(substr($head,0,6)==='GIF87a'||substr($head,0,6)==='GIF89a')$type='image/gif';elseif(substr($head,0,4)==='RIFF'&&substr($head,8,4)==='WEBP')$type='image/webp';
header('Content-Type: ' . (preg_match('#^image/(?:png|jpeg|gif|webp)$#i', $type) ? $type : 'image/jpeg'));
header('Cache-Control: public, max-age=86400');
echo $body;
