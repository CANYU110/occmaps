<?php
require __DIR__.'/config.php';require __DIR__.'/bootstrap.php';migrate_schema();
if(!table_exists('search_logs'))out(false);$keyword=substr(trim($_POST['keyword']??''),0,255);if($keyword==='')out(false);$type=substr(trim($_POST['type']??'place'),0,30);$label=substr(trim($_POST['label']??''),0,500);$found=(int)($_POST['found']??0);$ip=client_ip();$country=substr(trim($_POST['country']??''),0,80);$province=substr(trim($_POST['province']??''),0,80);
try{db()->prepare('INSERT INTO search_logs(keyword,search_type,result_label,result_found,ip_address,country,province) VALUES(?,?,?,?,?,?,?)')->execute([$keyword,$type,$label,$found?1:0,$ip,$country,$province]);out(true);}catch(Throwable $e){out(false);}
