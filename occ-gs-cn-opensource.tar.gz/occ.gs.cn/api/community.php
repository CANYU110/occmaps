<?php
ini_set('display_errors','0');
error_reporting(E_ALL & ~E_NOTICE & ~E_WARNING & ~E_DEPRECATED & ~E_STRICT);
ob_start();
require __DIR__.'/config.php';require __DIR__.'/bootstrap.php';$ip=client_ip();
if(empty($ip))$ip='0.0.0.0';
$action=$_REQUEST['action']??'';

function public_text($key,$max){return mb_substr(trim((string)($_POST[$key]??'')),0,$max);}
function queue_mail_after_response($callback){register_shutdown_function(function()use($callback){try{if(function_exists('fastcgi_finish_request'))fastcgi_finish_request();$callback();}catch(Throwable $e){}});}
function is_banned_email($email){
 $email=strtolower(trim((string)$email));
 if($email===''||!table_exists('banned_emails'))return false;
 $s=db()->prepare('SELECT id FROM banned_emails WHERE email=? LIMIT 1');
 $s->execute([$email]);
 return (bool)$s->fetchColumn();
}
function feedback_email($contact){return preg_match('/[^\s,;，；]+@[^\s,;，；]+/',(string)$contact,$m)?strtolower(trim($m[0])):'';}
function pending_submission_limit($email){
 if($email==='')return;
 $cfg=all_settings();
 $limit=max(1,min(100,(int)($cfg['submission_pending_limit']??5)));
 $s=db()->prepare("SELECT COUNT(*) FROM place_submissions WHERE status='pending' AND email=?");
 $s->execute([strtolower($email)]);
 if((int)$s->fetchColumn()>=$limit)fail("该邮箱待审核投稿已达到上限（{$limit} 条）；已有投稿审核完成后可继续投稿",429);
}
function require_email_code($cfg,$email){
 if($email===''||($cfg['submission_email_verification']??'1')!=='1')return true;
 $code=trim((string)($_POST['email_code']??''));
 if(!filter_var($email,FILTER_VALIDATE_EMAIL)||!preg_match('/^\d{6}$/',$code))fail('请填写有效邮箱并输入6位邮箱验证码',422);
 $s=db()->prepare('SELECT * FROM submission_email_codes WHERE email=? AND expires_at>=NOW() AND verified_at IS NULL ORDER BY id DESC LIMIT 1');
 $s->execute([$email]);$r=$s->fetch();
 if(!$r||$r['attempts']>=5)fail('邮箱验证码无效或已过期',422);
 db()->prepare('UPDATE submission_email_codes SET attempts=attempts+1 WHERE id=?')->execute([$r['id']]);
 if(!hash_equals($r['code_hash'],hash('sha256',$code)))fail('邮箱验证码错误',422);
 db()->prepare('UPDATE submission_email_codes SET verified_at=NOW() WHERE id=?')->execute([$r['id']]);
 return true;
}
function mail_text($template,$values){return str_replace(array_keys($values),array_values($values),(string)$template);}
function send_user_notice($to,$type,$data=[]){
 global $ip;
 if(!filter_var($to,FILTER_VALIDATE_EMAIL))return false;
 $cfg=all_settings();
 if(($cfg['smtp_enabled']??'0')!=='1')return false;
 require_once __DIR__.'/smtp.php';
 $defaults=[
  'submitted'=>['投稿已收到','您的投稿「{{place_name}}」已收到，管理员审核后会决定是否收录。'],
  'approved'=>['投稿已通过审核','您的投稿「{{place_name}}」已通过审核，已加入公开地图。'],
  'rejected'=>['投稿未通过审核','您的投稿「{{place_name}}」未通过审核。{{reason}}'],
  'feedback_received'=>['反馈已收到','您的反馈已收到，感谢您帮助我们完善{{site}}。']
 ];
 $fallback=$defaults[$type]??['站点通知','您有一条新的站点通知。'];
 $subject=trim((string)($cfg['mail_'.$type.'_subject']??''));
 $body=trim((string)($cfg['mail_'.$type.'_body']??''));
 $values=['{{site}}'=>(string)($cfg['site_name']??'全球灵异地点地图'),'{{place_name}}'=>(string)($data['place_name']??''),'{{name}}'=>(string)($data['name']??''),'{{reason}}'=>(string)($data['reason']??''),'{{content}}'=>(string)($data['content']??'')];
 return smtp_send_logged($cfg,$to,mail_text($subject!==''?$subject:$fallback[0],$values),mail_text($body!==''?$body:$fallback[1],$values),'notification_'.$type);
}
function send_admin_pending_notice($kind,$data){
 $cfg=all_settings();$to=trim((string)($cfg['smtp_admin_email']??''));
 if(!filter_var($to,FILTER_VALIDATE_EMAIL)||($cfg['smtp_enabled']??'0')!=='1')return false;
 require_once __DIR__.'/smtp.php';
 $defaults=['submission_pending'=>['收到新的投稿待审核','站点：{{site}}\n投稿人：{{name}}\n邮箱：{{email}}\n内容：{{content}}'],'feedback_pending'=>['收到新的反馈待处理','站点：{{site}}\n反馈人：{{name}}\n邮箱：{{email}}\n内容：{{content}}']];
 $fallback=$defaults[$kind];
 $values=['{{site}}'=>(string)($cfg['site_name']??'全球灵异地点地图'),'{{name}}'=>(string)($data['name']??'匿名'),'{{email}}'=>(string)($data['email']??'未填写'),'{{content}}'=>(string)($data['content']??'')];
 $subject=trim((string)($cfg[$kind.'_subject']??''));$body=trim((string)($cfg[$kind.'_body']??''));
 return smtp_send_logged($cfg,$to,mail_text($subject!==''?$subject:$fallback[0],$values),mail_text($body!==''?$body:$fallback[1],$values),$kind);
}

try{
 if($action==='submission_config'){
  $s=all_settings();$mode=function($k)use($s){$v=$s[$k]??'optional';return in_array($v,['hidden','optional','required'],true)?$v:'optional';};
  out(['site_name'=>'全球灵异地点地图','name'=>$mode('submission_name_mode'),'phone'=>$mode('submission_phone_mode'),'reason'=>$mode('submission_reason_mode'),'qq'=>$mode('submission_qq_mode'),'email'=>$mode('submission_email_mode'),'address'=>$mode('submission_address_mode'),'description'=>$mode('submission_description_mode'),'latitude'=>$mode('submission_latitude_mode'),'longitude'=>$mode('submission_longitude_mode'),'labels'=>['name'=>trim((string)($s['submission_name_label']??'您的名字'))?:'您的名字','phone'=>trim((string)($s['submission_phone_label']??'手机号'))?:'手机号','reason'=>trim((string)($s['submission_reason_label']??'投稿原因'))?:'投稿原因','qq'=>trim((string)($s['submission_qq_label']??'QQ'))?:'QQ','email'=>trim((string)($s['submission_email_label']??'邮箱'))?:'邮箱','address'=>trim((string)($s['submission_address_label']??'地址或地区'))?:'地址或地区','description'=>trim((string)($s['submission_description_label']??'地点介绍'))?:'地点介绍','latitude'=>trim((string)($s['submission_latitude_label']??'纬度'))?:'纬度','longitude'=>trim((string)($s['submission_longitude_label']??'经度'))?:'经度'],'media_mode'=>in_array($s['submission_media_mode']??'optional',['hidden','optional','required'],true)?$s['submission_media_mode']:'optional','feedback_media_mode'=>in_array($s['feedback_media_mode']??'optional',['hidden','optional','required'],true)?$s['feedback_media_mode']:'optional','code_interval'=>max(60,(int)($s['submission_email_code_interval']??60)),'code_hourly_limit'=>max(1,(int)($s['submission_email_code_hourly_limit']??5)),'email_verification'=>(($s['submission_email_verification']??'1')==='1'?'1':'0')]);
 }
 if($action==='send_email_code'){
  $cfg=all_settings();if(($cfg['submission_email_verification']??'1')!=='1')fail('邮箱验证未启用',422);
  $email=strtolower(public_text('email',180));if($email==='')$email=strtolower(feedback_email($_POST['contact']??''));
  if(!filter_var($email,FILTER_VALIDATE_EMAIL))fail('邮箱格式不正确',422);
  if(is_banned_email($email))fail('该邮箱已被禁止投稿或反馈',423);
  $hourLimit=max(1,min(100,(int)($cfg['submission_email_code_hourly_limit']??5)));$interval=max(60,min(86400,(int)($cfg['submission_email_code_interval']??60)));$s=db()->prepare('SELECT COUNT(*) FROM submission_email_codes WHERE (email=? OR ip_address=?) AND created_at>=DATE_SUB(NOW(),INTERVAL 1 HOUR)');$s->execute([$email,$ip]);
  if((int)$s->fetchColumn()>=$hourLimit)fail('验证码发送过于频繁，请一小时后再试',429);
  $s=db()->prepare('SELECT created_at FROM submission_email_codes WHERE email=? ORDER BY id DESC LIMIT 1');$s->execute([$email]);$last=$s->fetchColumn();
  if($last&&time()-strtotime($last)<$interval)fail('请等待'.$interval.'秒后再次发送',429);
  $code=(string)random_int(100000,999999);require_once __DIR__.'/smtp.php';
  smtp_send_logged($cfg,$email,'投稿邮箱验证码',"您的投稿邮箱验证码是：{$code}\r\n\r\n验证码10分钟内有效，请勿转发给他人。\r\n",'submission_code');
  db()->prepare('INSERT INTO submission_email_codes(email,code_hash,ip_address,expires_at) VALUES(?,?,?,DATE_ADD(NOW(),INTERVAL 10 MINUTE))')->execute([$email,hash('sha256',$code),$ip]);
  out(['sent'=>true,'message'=>'验证码已发送，请查看邮箱']);
 }
 function public_media_json(){ $raw=$_POST['media_json']??'[]';$rows=json_decode((string)$raw,true);if(!is_array($rows))return '[]';$out=[];foreach(array_slice($rows,0,12) as $row){$url=str_replace('\\','/',trim((string)($row['url']??'')));while(strpos($url,'../')===0)$url=substr($url,3);$type=($row['type']??'')==='video'?'video':'image';if(!preg_match('#^uploads/[a-zA-Z0-9_./-]+$#',$url))continue;$out[]=['type'=>$type,'url'=>substr($url,0,500)];}return json_encode($out,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);}
if($action==='submit_place'){
  $cfg=all_settings();$name=public_text('place_name',180);$address=public_text('address',500);$description=public_text('description',10000);$submitter=public_text('submitter_name',100);$phone=public_text('phone',40);$reason=public_text('reason',5000);$qq=public_text('qq',40);$email=strtolower(public_text('email',180));if($email==='')$email=strtolower(feedback_email($_POST['contact']??''));$lat=trim((string)($_POST['latitude']??''));$lng=trim((string)($_POST['longitude']??''));
  if($name==='')fail('地点名称必填',422);if($email!==''&&!filter_var($email,FILTER_VALIDATE_EMAIL))fail('邮箱格式不正确',422);if(is_banned_email($email))fail('该邮箱已被禁止投稿或反馈',423);
  foreach(['name'=>$submitter,'phone'=>$phone,'reason'=>$reason,'qq'=>$qq,'email'=>$email,'address'=>$address,'description'=>$description,'latitude'=>$lat,'longitude'=>$lng] as $key=>$value)if(($cfg['submission_'.$key.'_mode']??'optional')==='required'&&$value==='')fail('请填写所有必填项',422);
  pending_submission_limit($email);require_email_code($cfg,$email);
  if($lat!==''&&(!is_numeric($lat)||(float)$lat>90||(float)$lat<-90))fail('纬度无效',422);if($lng!==''&&(!is_numeric($lng)||(float)$lng>180||(float)$lng<-180))fail('经度无效',422);
  $media=public_media_json();$mediaMode=in_array($cfg['submission_media_mode']??'optional',['hidden','optional','required'],true)?$cfg['submission_media_mode']:'optional';if($mediaMode==='required'&&$media==='[]')fail('请至少上传一张图片或视频',422);$s=db()->prepare('INSERT INTO place_submissions(place_name,address,latitude,longitude,description,media_json,submitter_name,phone,reason,qq,email,ip_address) VALUES(?,?,NULLIF(?,\'\'),NULLIF(?,\'\'),?,?,?,?,?,?,?,?)');
  $s->execute([$name,$address,$lat,$lng,$description,$media,$submitter,$phone,$reason,$qq,$email,$ip]);$id=(int)db()->lastInsertId();
  queue_mail_after_response(function()use($email,$name,$submitter,$reason,$description){send_user_notice($email,'submitted',['place_name'=>$name,'name'=>$submitter]);send_admin_pending_notice('submission_pending',['name'=>$submitter,'email'=>$email,'content'=>$reason!==''?$reason:$description]);});
  out(['id'=>$id,'message'=>'投稿已收到，管理员审核后会决定是否收录']);
 }
 if($action==='submit_feedback'){
  $cfg=all_settings();$name=public_text('name',100);$contact=public_text('contact',180);$type=public_text('feedback_type',40);$content=public_text('content',10000);$email=feedback_email($contact);
  if($content==='')fail('请填写反馈或建议内容',422);if(!in_array($type,['建议','纠错','功能问题','内容投诉','其他'],true))$type='其他';
  if(($cfg['submission_email_verification']??'1')==='1'&&!filter_var($email,FILTER_VALIDATE_EMAIL))fail('启用邮箱验证时，必须填写有效邮箱并完成邮箱验证码',422);
  if($email!==''&&is_banned_email($email))fail('该邮箱已被禁止投稿或反馈',423);
  require_email_code($cfg,$email);
  $media=public_media_json();$mediaMode=in_array($cfg['feedback_media_mode']??'optional',['hidden','optional','required'],true)?$cfg['feedback_media_mode']:'optional';if($mediaMode==='required'&&$media==='[]')fail('请至少上传一张图片或视频',422);db()->prepare('INSERT INTO feedback_messages(name,contact,feedback_type,content,media_json,ip_address) VALUES(?,?,?,?,?,?)')->execute([$name,$contact,$type,$content,$media,$ip]);$id=(int)db()->lastInsertId();
  queue_mail_after_response(function()use($name,$email,$content){send_user_notice($email,'feedback_received',['name'=>$name,'content'=>$content]);send_admin_pending_notice('feedback_pending',['name'=>$name,'email'=>$email,'content'=>$content]);});
  out(['id'=>$id,'message'=>'反馈已收到，感谢您的建议']);
 }
 fail('未知操作',404);
}catch(Throwable $e){fail('提交失败：'.$e->getMessage(),500);}