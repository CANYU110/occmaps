<?php
function smtp_read($fp){
$text='';
while(($line=fgets($fp,515))!==false){
$text.=$line;
if(strlen($line)>=4&&$line[3]===' ')break;
}
return $text;
}
function smtp_expect($fp,$codes){
$r=smtp_read($fp);
$code=(int)substr($r,0,3);
if(!in_array($code,$codes,true))throw new RuntimeException('SMTP '.$code);
return $r;
}
function smtp_cmd($fp,$cmd,$codes){
fwrite($fp,$cmd."\r\n");
return smtp_expect($fp,$codes);
}
function smtp_send_text($cfg,$to,$subjectText,$body){
$host=trim($cfg['smtp_host']??'');
$port=(int)($cfg['smtp_port']??465);
$enc=$cfg['smtp_encryption']??'ssl';
$user=trim($cfg['smtp_username']??'');
$pass=(string)($cfg['smtp_password']??'');
$from=trim($cfg['smtp_from_email']??$user);
if(!$host||!$port||!filter_var($from,FILTER_VALIDATE_EMAIL)||!filter_var($to,FILTER_VALIDATE_EMAIL))throw new RuntimeException('SMTP配置不完整：请检查主机、端口、发件邮箱');
$target=($enc==='ssl'?'ssl://':'').$host.':'.$port;
$fp=@stream_socket_client($target,$errno,$errstr,8,STREAM_CLIENT_CONNECT);
if(!$fp)throw new RuntimeException('SMTP连接失败：'.$errstr.' ('.$errno.')');
stream_set_timeout($fp,8);
smtp_expect($fp,[220]);
smtp_cmd($fp,'EHLO occ.gs.cn',[250]);
if($enc==='tls'){
smtp_cmd($fp,'STARTTLS',[220]);
if(!stream_socket_enable_crypto($fp,true,STREAM_CRYPTO_METHOD_TLS_CLIENT))throw new RuntimeException('TLS失败');
smtp_cmd($fp,'EHLO occ.gs.cn',[250]);
}
if($user!==''){
smtp_cmd($fp,'AUTH LOGIN',[334]);
smtp_cmd($fp,base64_encode($user),[334]);
smtp_cmd($fp,base64_encode($pass),[235]);
}
smtp_cmd($fp,'MAIL FROM:<'.$from.'>',[250]);
smtp_cmd($fp,'RCPT TO:<'.$to.'>',[250,251]);
smtp_cmd($fp,'DATA',[354]);
$subject='=?UTF-8?B?'.base64_encode($subjectText).'?=';
$name='全球灵异地点地图';
$headers='From: =?UTF-8?B?'.base64_encode($name).'?= <'.$from.">\r\n".'To: <'.$to.">\r\n".'Subject: '.$subject."\r\n".'MIME-Version: 1.0'."\r\n".'Content-Type: text/plain; charset=UTF-8'."\r\n";
$payload=preg_replace('/(?m)^\\./','..',$headers."\r\n".$body);
fwrite($fp,$payload."\r\n.\r\n");
smtp_expect($fp,[250]);
smtp_cmd($fp,'QUIT',[221]);
fclose($fp);
return true;
}
function smtp_log($type,$to,$subject,$body,$status,$error=''){
try{
if(function_exists('table_exists')&&table_exists('smtp_send_logs')){if(function_exists('column_exists')&&column_exists('smtp_send_logs','body_content'))db()->prepare('INSERT INTO smtp_send_logs(mail_type,recipient,subject,body_content,status,error_message,ip_address) VALUES(?,?,?,?,?,?,?)')->execute([substr($type,0,40),substr($to,0,180),substr($subject,0,200),$body,$status==='success'?'success':'failed',substr($error,0,500),function_exists('client_ip')?client_ip():'']);else db()->prepare('INSERT INTO smtp_send_logs(mail_type,recipient,subject,status,error_message,ip_address) VALUES(?,?,?,?,?,?)')->execute([substr($type,0,40),substr($to,0,180),substr($subject,0,200),$status==='success'?'success':'failed',substr($error,0,500),function_exists('client_ip')?client_ip():'']);}
}catch(Throwable $e){}
}
function smtp_send_logged($cfg,$to,$subject,$body,$type){
try{
smtp_send_text($cfg,$to,$subject,$body);
smtp_log($type,$to,$subject,$body,'success','');
return true;
}catch(Throwable $e){
$smtp_error=$e->getMessage();
smtp_log($type,$to,$subject,$body,'failed',$smtp_error);
throw $e;
}
}
function smtp_send_login_notice($cfg,$username,$ip,$ua){
if(($cfg['smtp_enabled']??'0')!=='1')return false;
$to=trim($cfg['smtp_admin_email']??'');
$body="管理员账号：{$username}\r\n登录时间：".date('Y-m-d H:i:s')."\r\nIP：{$ip}\r\n浏览器：{$ua}\r\n";
return smtp_send_logged($cfg,$to,'后台登录通知',$body,'login_notice');
}
function esc_html($s){return htmlspecialchars($s,ENT_QUOTES,'UTF-8');}