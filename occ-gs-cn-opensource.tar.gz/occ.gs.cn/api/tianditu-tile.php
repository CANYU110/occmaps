<?php
require __DIR__.'/config.php';
require __DIR__.'/bootstrap.php';

$settings=all_settings();
$token=trim((string)($settings['tianditu_token']??''));
$enabled=trim((string)($settings['tianditu_enabled']??'0'))==='1';
if($token===''||!$enabled){http_response_code(404);exit;}
$z=max(0,min(18,(int)($_GET['z']??0)));
$x=max(0,(int)($_GET['x']??0));
$y=max(0,(int)($_GET['y']??0));
$layer=($_GET['layer']??'vec')==='cva'?'cva':'vec';
$host='t'.(($x+$y)%8);
$url='https://'.$host.'.tianditu.gov.cn/DataServer?T='.rawurlencode($layer.'_w').'&x='.$x.'&y='.$y.'&l='.$z.'&tk='.rawurlencode($token);
$body=false;$type='';$status=0;
if(function_exists('curl_init')){
    $c=curl_init($url);
    curl_setopt_array($c,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_CONNECTTIMEOUT=>4,CURLOPT_TIMEOUT=>12,CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_USERAGENT=>'GlobalParanormalMap/6.1']);
    $body=curl_exec($c);$status=(int)curl_getinfo($c,CURLINFO_RESPONSE_CODE);$type=(string)curl_getinfo($c,CURLINFO_CONTENT_TYPE);curl_close($c);
}else{
    $ctx=stream_context_create(['http'=>['timeout'=>12,'ignore_errors'=>true,'header'=>"User-Agent: GlobalParanormalMap/6.1\r\n"],'https'=>['timeout'=>12,'ignore_errors'=>true,'header'=>"User-Agent: GlobalParanormalMap/6.1\r\n"]]);
    $body=@file_get_contents($url,false,$ctx);$status=$body===false?502:200;
}
if($body===false||$status<200||$status>=300){http_response_code(502);exit;}
$head=substr((string)$body,0,12);
if(substr($head,0,3)==="\xFF\xD8\xFF")$type='image/jpeg';
elseif(substr($head,0,8)==="\x89PNG\r\n\x1a\n")$type='image/png';
elseif(substr($head,0,6)==='GIF87a'||substr($head,0,6)==='GIF89a')$type='image/gif';
elseif(substr($head,0,4)==='RIFF'&&substr($head,8,4)==='WEBP')$type='image/webp';
if(!preg_match('#^image/(?:jpeg|png|gif|webp)$#i',$type))$type='image/jpeg';
header('Content-Type: '.$type);header('Cache-Control: public, max-age=86400');echo $body;