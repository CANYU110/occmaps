<?php
$id=isset($_GET['id'])?(int)$_GET['id']:0;
?><!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>地点档案 · 全球灵异地点地图</title>
<link rel="icon" href="assets/site-logo.webp?v=6.1.7.64" type="image/webp" sizes="any">
<link rel="stylesheet" href="assets/place-detail.css?v=6.1.7.95"><link rel="stylesheet" href="assets/v61769-place-media.css?v=6.1.7.84"><link rel="stylesheet" href="assets/v61748-mobile-footer-sync.css?v=6.1.7.51"><link rel="stylesheet" href="assets/v61793-place-mobile.css?v=6.1.7.95">
<link rel="stylesheet" href="assets/archive-ui.css?v=7.2.0"></head>
<body class="place-detail-page">
<header class="detail-head"><a id="detailBrand" class="detail-brand" href="./"><img id="detailBrandLogo" src="assets/site-logo.webp?v=6.1.7.64" alt="网站 Logo"><span>Ghost</span> Map</a><nav id="detailMenu" class="detail-menu" aria-label="头部菜单"></nav><a class="detail-back" href="javascript:history.back()">返回浏览</a></header>
<main id="placeDetail" class="detail-main" data-place-id="<?= $id ?>"><p class="detail-loading">正在读取地点档案……</p></main>
<footer id="detailFooter" class="detail-footer compact">正在读取页脚…</footer>
<script src="assets/place-shell.js?v=6.1.7.69"></script><script src="assets/place-detail.js?v=6.1.7.95"></script><script src="external-config.php?v=6.1.7.51"></script><script src="assets/external-redirect.js?v=6.1.7.63"></script>

<!-- TG-CREDIT:v1 版权归中国灵异网所有 https://talkghost.com 请勿删除 -->
<script src="assets/credit-guard.js?v=1.0.0"></script>
</body>
</html>