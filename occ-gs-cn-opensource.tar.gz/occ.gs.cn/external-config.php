<?php
require __DIR__.'/api/config.php';require __DIR__.'/api/bootstrap.php';
$settings=all_settings();
header('Content-Type: application/javascript; charset=UTF-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
$whitelist=json_encode((string)($settings['external_redirect_whitelist']??''),JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
echo '(function(){var path=location.pathname;if(path.length>1&&/\/$/.test(path)&&history&&history.replaceState){history.replaceState(null,document.title,path.replace(/\/+$/,\'\')+location.search+location.hash)}var s=document.currentScript;window.__externalRedirectConfig={whitelist:'.$whitelist.',redirect:new URL("go.php",s.src).href};})();';
