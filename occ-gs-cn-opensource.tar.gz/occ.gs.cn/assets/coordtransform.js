var CT_PI=3.1415926535897932384626,CT_A=6378245.0,CT_EE=0.00669342162296594323;
/* 用中国大陆近似边界替代旧矩形，避免日本、韩国等地被误判为 GCJ-02。 */
var CT_CHINA_POLYS=[[[18,108],[20.5,99],[24,97],[28,88],[33,79],[40,73.5],[46.5,82],[49.5,87],[54,120],[49,135],[43,132],[40,124],[35,121],[30,122.5],[25,119],[21.5,113.5]],[[18,108.5],[20.3,109],[20.3,111.2],[18,111.2]],[[21.7,119.2],[25.5,119.2],[25.5,122.2],[21.7,122.2]]];
function ctInPoly(lng,lat,poly){var inside=false;for(var i=0,j=poly.length-1;i<poly.length;j=i++){var yi=poly[i][0],xi=poly[i][1],yj=poly[j][0],xj=poly[j][1];if(((yi>lat)!==(yj>lat))&&(lng<(xj-xi)*(lat-yi)/(yj-yi)+xi))inside=!inside}return inside}
function ctInChina(lng,lat){for(var i=0;i<CT_CHINA_POLYS.length;i++)if(ctInPoly(lng,lat,CT_CHINA_POLYS[i]))return true;return false}
/* 高德底图覆盖范围与 GCJ-02 纠偏范围不同：南海岛礁仍使用高德底图，但不做大陆坐标纠偏。 */
var CT_AMAP_POLYS=[[[3,105],[3,135],[25,135],[25,119],[30,122],[35,121],[40,124],[46.5,135],[54,120],[49.5,87],[40,73.5],[28,88],[20,99],[10,105]],[[18,108],[20.5,108],[20.5,112],[18,112]],[[3,105],[10,105],[10,120],[3,120]]];
/* 高德/GCJ-02 只用于中国大陆；港澳台与海外一律保持 WGS-84 并走全球底图。 */
function ctInAmapCoverage(lng,lat){
  lng=+lng;lat=+lat;
  if(!ctInChina(lng,lat))return false;
  var taiwan=lat>=21.6&&lat<=25.6&&lng>=118.9&&lng<=122.3;
  var hongKong=lat>=22.08&&lat<=22.58&&lng>=113.78&&lng<=114.52;
  var macao=lat>=22.05&&lat<=22.25&&lng>=113.45&&lng<=113.64;
  if(taiwan||hongKong||macao)return false;
  for(var i=0;i<CT_AMAP_POLYS.length;i++)if(ctInPoly(lng,lat,CT_AMAP_POLYS[i]))return true;
  return false;
}
function ctOut(lng,lat){return !ctInChina(lng,lat)}
function ctLat(x,y){var r=-100+2*x+3*y+.2*y*y+.1*x*y+.2*Math.sqrt(Math.abs(x));r+=(20*Math.sin(6*x*CT_PI)+20*Math.sin(2*x*CT_PI))*2/3;r+=(20*Math.sin(y*CT_PI)+40*Math.sin(y/3*CT_PI))*2/3;r+=(160*Math.sin(y/12*CT_PI)+320*Math.sin(y*CT_PI/30))*2/3;return r}
function ctLng(x,y){var r=300+x+2*y+.1*x*x+.1*x*y+.1*Math.sqrt(Math.abs(x));r+=(20*Math.sin(6*x*CT_PI)+20*Math.sin(2*x*CT_PI))*2/3;r+=(20*Math.sin(x*CT_PI)+40*Math.sin(x/3*CT_PI))*2/3;r+=(150*Math.sin(x/12*CT_PI)+300*Math.sin(x/30*CT_PI))*2/3;return r}
function wgs84ToGcj02(lng,lat,force){if(!force&&ctOut(lng,lat))return[lng,lat];var dLat=ctLat(lng-105,lat-35),dLng=ctLng(lng-105,lat-35),rad=lat/180*CT_PI,m=Math.sin(rad);m=1-CT_EE*m*m;var s=Math.sqrt(m);dLat=dLat*180/((CT_A*(1-CT_EE))/(m*s)*CT_PI);dLng=dLng*180/(CT_A/s*Math.cos(rad)*CT_PI);return[lng+dLng,lat+dLat]}
function gcj02ToWgs84(lng,lat){var g=wgs84ToGcj02(lng,lat);return[lng*2-g[0],lat*2-g[1]]}
/* 迭代反解：供高德 GCJ-02 选点写回 WGS-84 使用，避免一阶近似在部分城市产生米级残差。 */
function gcj02ToWgs84Exact(lng,lat,force){if(!force&&ctOut(lng,lat))return[lng,lat];var wLng=lng,wLat=lat,i,g;for(i=0;i<8;i++){g=wgs84ToGcj02(wLng,wLat,force);wLng-=g[0]-lng;wLat-=g[1]-lat;if(Math.abs(g[0]-lng)<1e-9&&Math.abs(g[1]-lat)<1e-9)break}return[wLng,wLat]}
