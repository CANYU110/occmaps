(function(){
'use strict';
function esc(v){return String(v==null?'':v).replace(/[&<>"']/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})}
function sourceUrl(v){var u=String(v||'').trim().replace(/\\/g,'/');while(u.indexOf('../')===0)u=u.slice(3);return /^https?:\/\//i.test(u)||u.charAt(0)==='/'?u:'../'+u}
function closeBox(box){if(box&&box.parentNode)box.parentNode.removeChild(box);document.removeEventListener('keydown',key)}
function key(e){if(e.key==='Escape'){var box=document.getElementById('adminMediaLightboxStandalone');closeBox(box)}}
function openMedia(button){
 var old=document.getElementById('adminMediaLightboxStandalone');if(old)closeBox(old);
 var type=button.getAttribute('data-media-type')==='video'?'video':'image',url=sourceUrl(button.getAttribute('data-media-url')),title=button.getAttribute('data-media-title')|| (type==='video'?'视频附件':'图片附件');
 if(!url)return;
 var box=document.createElement('div');box.id='adminMediaLightboxStandalone';box.className='photo-lightbox admin-media-lightbox admin-media-lightbox-standalone';
 box.innerHTML='<button type="button" class="photo-lightbox-close" aria-label="关闭">×</button><figure></figure>';
 var figure=box.querySelector('figure');
 if(type==='video')figure.innerHTML='<video controls autoplay playsinline preload="metadata" src="'+esc(url)+'"></video><figcaption>'+esc(title)+'</figcaption>';
 else figure.innerHTML='<img src="'+esc(url)+'" alt="'+esc(title)+'"><figcaption>'+esc(title)+'</figcaption>';
 document.body.appendChild(box);box.querySelector('.photo-lightbox-close').onclick=function(e){e.preventDefault();e.stopPropagation();closeBox(box)};box.onclick=function(e){if(e.target===box)closeBox(box)};document.addEventListener('keydown',key);
}
document.addEventListener('click',function(e){
 var button=e.target&&e.target.closest?e.target.closest('[data-media-open]'):null;
 if(!button)return;
 e.preventDefault();e.stopPropagation();if(e.stopImmediatePropagation)e.stopImmediatePropagation();openMedia(button);
},true);
})();
