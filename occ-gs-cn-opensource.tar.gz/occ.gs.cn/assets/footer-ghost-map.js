(function(){
'use strict';
function applyFooterTitle(){
  var footer=document.getElementById('siteFooterRich');
  if(!footer||footer.dataset.ghostMapTitle==='1')return;
  var heading=footer.querySelector('.footer-brand-head h2');
  if(!heading)return;
  heading.dataset.originalTitle=heading.textContent||'';
  heading.innerHTML='<a class="footer-site-title" href="./" aria-label="返回本站首页"><span class="footer-site-title-ghost">Ghost</span> <span class="footer-site-title-map">Map</span></a>';
  footer.dataset.ghostMapTitle='1';
}
var observer=new MutationObserver(applyFooterTitle);
observer.observe(document.documentElement,{childList:true,subtree:true});
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',applyFooterTitle);else applyFooterTitle();
})();
