/* ES5/旧版移动浏览器兼容层 */
(function(){
 if(!String.prototype.padStart){String.prototype.padStart=function(n,s){var x=String(this),p=String(s||' ');while(x.length<n)x=p+x;return x.slice(-n)}}
 if(!Array.isArray){Array.isArray=function(a){return Object.prototype.toString.call(a)==='[object Array]'}}
 if(!Object.keys){Object.keys=function(o){var a=[],k;for(k in o)if(Object.prototype.hasOwnProperty.call(o,k))a.push(k);return a}}
 if(!Object.values){Object.values=function(o){return Object.keys(o).map(function(k){return o[k]})}}
 if(!window.Set){window.Set=function(a){this._=[];var t=this;(a||[]).forEach(function(x){t.add(x)})};Set.prototype.has=function(x){return this._.indexOf(x)>-1};Set.prototype.add=function(x){if(!this.has(x))this._.push(x);return this};Set.prototype.delete=function(x){var i=this._.indexOf(x);if(i>-1)this._.splice(i,1);return i>-1};Object.defineProperty(Set.prototype,'size',{get:function(){return this._.length}})}
 if(!Array.from){Array.from=function(x){return x&&x._?x._.slice():Array.prototype.slice.call(x)}}
 if(!window.URLSearchParams){window.URLSearchParams=function(init){this.p=[];var k;if(init)for(k in init)if(Object.prototype.hasOwnProperty.call(init,k))this.append(k,init[k])};URLSearchParams.prototype.append=function(k,v){this.p.push([k,v])};URLSearchParams.prototype.set=function(k,v){for(var i=this.p.length-1;i>=0;i--)if(this.p[i][0]===k)this.p.splice(i,1);this.append(k,v)};URLSearchParams.prototype.toString=function(){return this.p.map(function(x){return encodeURIComponent(x[0])+'='+encodeURIComponent(x[1])}).join('&')}}
 if(window.Promise&&!Promise.prototype.finally){Promise.prototype.finally=function(cb){var P=this.constructor;return this.then(function(v){return P.resolve(cb()).then(function(){return v})},function(e){return P.resolve(cb()).then(function(){throw e})})}}
})();
