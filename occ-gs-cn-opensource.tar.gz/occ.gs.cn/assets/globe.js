/* 参考站同参数地球：真实贴图、克制大气辉光、星尘、坐标联动
   v7.2.0 手机端重构：
     · 配色并入「旧纸 · 朱砂 · 夜墨」，去掉全部冷蓝/青绿/荧光红
     · 竖屏按短边视场角取景，地球完整入画；缩放范围随屏幕比例动态化
     · 桌面端自转，手机端不自转（auto = !isPhone）
     · 手机端标记重做：光柱 + 光环 + 光点，不再淡出
     · 新增点位轮播卡片（自动前进并平滑转向该点位）+ 竖向滑动缩放条 */
(function(){
'use strict';
if(typeof THREE==='undefined')return;
var el=document.getElementById('globe');if(!el)return;

/* ---------- 调色板 ----------
   UI 外壳走「旧纸 · 朱砂 · 夜墨」，但地球本体要写实：
   海洋是蓝的、陆地是绿褐的、星空是白与蓝白。
   两者靠同一套赭金/朱砂的标记与卡片缝合。 */
var C_BRASS=0xb8813f,      /* 赭金（UI 强调） */
    C_BRASS_L=0xe0b45e,    /* 亮赭金（标记） */
    C_CINNABAR=0xc0503a,   /* 朱砂（高等级标记） */
    C_GRID=0x9fb2c4,       /* 经纬网：冷白细线，贴近真实经纬仪 */
    C_ATMO=0x8fb8d8,       /* 大气层：蓝白辉光 */
    C_STAR_A=0xd6e2f0, C_STAR_B=0xffffff, C_STAR_C=0xffe3bd, C_STAR_D=0xffffff;

var isPhone=!!(window.matchMedia&&(window.matchMedia('(max-width:720px)').matches||window.matchMedia('(pointer:coarse)').matches&&Math.min(screen.width,screen.height)<=720));

var scene=new THREE.Scene(),camera=new THREE.PerspectiveCamera(34,1,.1,140),renderer;
var globe=new THREE.Group(),markers=[],fadingMarkers=[],clickables=[],drag=false,moved=false,
    last={x:0,y:0},rx=0,ry=0,distance=10.8,
    auto=!isPhone,                       /* 手机端不自转 */
    transitioning=false,zoomIntent=0,starLayers=[],markerEffects=[],hovered=null,
    markerCycleTimer=0,markerCycleIndex=0,desktopBatchSize=10,phoneBatchSize=10,
    heldMarkerId='',heldMarkerPoint=null,
    skyParallax={x:0,y:0,targetX:0,targetY:0},
    phoneSelectedMarkerId='';

/* 取景与缩放范围（由屏幕比例算出，不再写死） */
var GLOBE_R=3,fitDist=10.8,minDist=7.3,maxDist=13.5;
var STAR_BASE=10.8;                     /* 星空基准距离，随缩放整体推移 */
/* 平滑转向 */
var turn=null;
/* 轮播 */
var carouselEl=null,gcThumb=null,gcSeal=null,gcIdx=null,gcCat=null,gcTitle=null,gcSub=null,
    gcProg=null,gcPlay=null,carouselCard=null,
    carouselList=[],carouselIdx=-1,carouselPaused=false,carouselT0=0,carouselDur=4600,
    carouselActiveId='',carouselHoldUntil=0,lastPoints=[],lastColorFn=null,activeExtraGroup=null;
/* 缩放滑条 */
var zoomEl=null,gzTrack=null,gzFill=null,gzKnob=null,hintEl=null;
var MOBILE_UI_BUILT=false;

var ray=new THREE.Raycaster(),mouse=new THREE.Vector2();scene.add(globe);
renderer=new THREE.WebGLRenderer({alpha:true,antialias:true,powerPreference:'high-performance'});
renderer.setPixelRatio(Math.min(window.devicePixelRatio||1,1.75));renderer.outputEncoding=THREE.sRGBEncoding;renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=.98;el.appendChild(renderer.domElement);

/* 取景：按短边视场角算出让地球完整入画的距离 */
function shortHalfFov(){var vf=THREE.MathUtils.degToRad(camera.fov),hf=2*Math.atan(Math.tan(vf/2)*camera.aspect);return Math.min(vf,hf)/2}
function computeFit(){
  var margin=isPhone?1.05:1.16;
  fitDist=GLOBE_R*margin/Math.tan(shortHalfFov());
  minDist=fitDist*(isPhone?.42:.62);
  maxDist=fitDist*(isPhone?1.55:1.26);
}
function resize(){
  var w=el.clientWidth||innerWidth,h=el.clientHeight||innerHeight;
  renderer.setSize(w,h,false);camera.aspect=w/h;camera.updateProjectionMatrix();
  var first=!el.__framed;computeFit();
  if(first){distance=fitDist;el.__framed=1}
  else if(distance>maxDist||distance<minDist){distance=Math.max(minDist,Math.min(maxDist,distance))}
  syncZoomUI();
}
resize();window.addEventListener('resize',resize);
camera.position.set(0,0,distance);
/* 光照以「均匀」为先：这是给人看档案用的地球，不是天文模拟。
   环境光占主导，平行光只负责给出一点体积感，避免半个球全黑、标记看不见。 */
var fill=new THREE.HemisphereLight(0x5a708a,0x10141a,.62);scene.add(fill);
var key=new THREE.DirectionalLight(0xfff6ea,1.0);key.position.set(-4.5,3.2,6.5);scene.add(key);
var rim=new THREE.DirectionalLight(0xb8813f,.20);rim.position.set(5,-2.5,-5);scene.add(rim);

var texture=new THREE.TextureLoader().load('assets/earth-atmos-2048.jpg',function(){renderer.render(scene,camera)},undefined,function(){el.classList.add('texture-failed')});
texture.encoding=THREE.sRGBEncoding;texture.anisotropy=Math.min(8,renderer.capabilities.getMaxAnisotropy());
/* 贴图保持原色：海洋蓝、陆地绿褐，不做任何暖色偏移。
   完全去掉 specular —— Phong 的高光是全球统一的，不区分海陆，
   只要留一点就会在洋面上糊出一枚假的「月亮」。
   想要海面反光得用自定义 shader 按贴图亮度做遮罩，这里不值得。
   emissive 只给夜面留一点「地照」，让背光侧不至于全黑。 */
var earthMaterial=new THREE.MeshPhongMaterial({color:0xffffff,emissive:0x1a2028,emissiveMap:texture,emissiveIntensity:.45,shininess:1,specular:0x000000,map:texture});
var earth=new THREE.Mesh(new THREE.SphereGeometry(GLOBE_R,128,128),earthMaterial);globe.add(earth);
/* 大气层：背面 fresnel，只在地球轮廓外缘留下一圈很淡的蓝白辉光 */
var atmosphere=new THREE.Mesh(new THREE.SphereGeometry(GLOBE_R*1.115,64,64),new THREE.ShaderMaterial({
  transparent:true,depthWrite:false,side:THREE.BackSide,blending:THREE.AdditiveBlending,
  uniforms:{uColor:{value:new THREE.Color(C_ATMO)},uPower:{value:3.4},uIntensity:{value:.62}},
  vertexShader:'varying vec3 vN;varying vec3 vV;void main(){vN=normalize(normalMatrix*normal);vec4 mv=modelViewMatrix*vec4(position,1.0);vV=normalize(-mv.xyz);gl_Position=projectionMatrix*mv;}',
  fragmentShader:'uniform vec3 uColor;uniform float uPower;uniform float uIntensity;varying vec3 vN;varying vec3 vV;void main(){float f=pow(1.0-abs(dot(vN,vV)),uPower);gl_FragColor=vec4(uColor,f*uIntensity);}'
}));
globe.add(atmosphere);

var geoGuides=new THREE.Group(),guideLabels=[],geoFeatures=new THREE.Group();globe.add(geoGuides);globe.add(geoFeatures);
function guideLine(points,color,opacity,width){var geo=new THREE.BufferGeometry().setFromPoints(points),mat=new THREE.LineBasicMaterial({color:color,transparent:true,opacity:opacity,depthWrite:false,depthTest:true,blending:THREE.NormalBlending,linewidth:width||1});var line=new THREE.Line(geo,mat);geoGuides.add(line);return line}
function guideLoop(points,color,opacity){var geo=new THREE.BufferGeometry().setFromPoints(points),mat=new THREE.LineBasicMaterial({color:color,transparent:true,opacity:opacity,depthWrite:false,depthTest:true,blending:THREE.NormalBlending});var line=new THREE.LineLoop(geo,mat);geoGuides.add(line);return line}
function latitudePoints(lat,radius){var out=[];for(var lng=-180;lng<=180;lng+=2)out.push(llv(lat,lng,radius));return out}
function longitudePoints(lng,radius){var out=[];for(var lat=-90;lat<=90;lat+=2)out.push(llv(lat,lng,radius));return out}
[-60,-30,30,60].forEach(function(lat){guideLine(latitudePoints(lat,GLOBE_R*1.004),C_GRID,.13,1)});
[-150,-120,-90,-60,-30,0,30,60,90,120,150,180].forEach(function(lng){guideLine(longitudePoints(lng,GLOBE_R*1.004),C_GRID,.11,1)});
guideLine(latitudePoints(0,GLOBE_R*1.008),C_BRASS_L,.72,2);
var activeLatitudeLine=guideLoop(latitudePoints(30,GLOBE_R*1.014),C_BRASS_L,.9),activeLatitudeLabel=null;
function labelTexture(text,color){
  var c=document.createElement('canvas');c.width=512;c.height=96;var x=c.getContext('2d');
  x.clearRect(0,0,c.width,c.height);
  x.fillStyle='rgba(13,11,7,.84)';x.strokeStyle=color;x.lineWidth=2;
  x.beginPath();x.rect(4,4,504,86);x.fill();x.stroke();
  x.fillStyle=color;x.font='600 26px "STKaiti",KaiTi,Georgia,serif';x.textAlign='center';x.textBaseline='middle';
  x.fillText(text,256,48);var t=new THREE.CanvasTexture(c);t.encoding=THREE.sRGBEncoding;return t;
}
function addGuideLabel(text,lat,lng,color){var mat=new THREE.SpriteMaterial({map:labelTexture(text,color),transparent:true,depthTest:false,depthWrite:false}),sprite=new THREE.Sprite(mat);sprite.position.copy(llv(lat,lng,GLOBE_R*1.043));sprite.scale.set(1.55,.29,1);sprite.userData={base:llv(lat,lng,GLOBE_R*1.043)};geoGuides.add(sprite);guideLabels.push(sprite);return sprite}
/* 手机屏小，两个标签贴到球体边缘会糊成黑块，索性不挂；线条本身已经说明一切 */
if(!isPhone){
  addGuideLabel('赤道  0°',0,8,'#b8813f');
  activeLatitudeLabel=addGuideLabel('北纬 30° ±5°',30,8,'#b8813f');
}
function updateActiveLatitude(time){
  var lat=30+Math.sin(time*.00035)*5,pts=latitudePoints(lat,GLOBE_R*1.014),attr=activeLatitudeLine.geometry.getAttribute('position');
  for(var i=0;i<pts.length;i++)attr.setXYZ(i,pts[i].x,pts[i].y,pts[i].z);
  attr.needsUpdate=true;
  if(activeLatitudeLabel){activeLatitudeLabel.position.copy(llv(lat,8,GLOBE_R*1.043));activeLatitudeLabel.userData.base=llv(lat,8,GLOBE_R*1.043)}
}

function makeStars(count,minR,maxR,color,size,opacity,depth){
  var desktopBoost=isPhone?1:1.72,
      viewAspect=Math.max(1,(el.clientWidth||innerWidth)/Math.max(1,(el.clientHeight||innerHeight))),
      spreadBoost=isPhone?1:Math.min(2.15,viewAspect*1.16);
  count=Math.round(count*desktopBoost);
  var data=new Float32Array(count*3),phases=new Float32Array(count),speeds=new Float32Array(count),sizes=new Float32Array(count);
  for(var i=0;i<count;i++){
    var spreadX=minR*spreadBoost,spreadY=maxR;
    data[i*3]=(Math.random()-.5)*spreadX;data[i*3+1]=(Math.random()-.5)*spreadY;data[i*3+2]=-2-Math.random()*10;
    phases[i]=Math.random()*Math.PI*2;speeds[i]=.65+Math.random()*1.75;sizes[i]=size*(.75+Math.random()*1.1);
  }
  var geo=new THREE.BufferGeometry();
  geo.setAttribute('position',new THREE.BufferAttribute(data,3));
  geo.setAttribute('aPhase',new THREE.BufferAttribute(phases,1));
  geo.setAttribute('aSpeed',new THREE.BufferAttribute(speeds,1));
  geo.setAttribute('aSize',new THREE.BufferAttribute(sizes,1));
  var mat=new THREE.ShaderMaterial({transparent:true,depthWrite:false,blending:THREE.AdditiveBlending,uniforms:{uTime:{value:0},uColor:{value:new THREE.Color(color)},uOpacity:{value:opacity},uPixelRatio:{value:Math.min(window.devicePixelRatio||1,1.75)}},vertexShader:'attribute float aPhase;attribute float aSpeed;attribute float aSize;uniform float uTime;uniform float uPixelRatio;varying float vAlpha;void main(){float wave=sin(uTime*aSpeed+aPhase);float wave2=sin(uTime*aSpeed*2.31+aPhase*0.71);float glint=pow(max(0.0,sin(uTime*aSpeed*0.41+aPhase*1.73)),8.0);vAlpha=0.26+0.50*(wave*0.5+0.5)+0.14*(wave2*0.5+0.5)+0.90*glint;vec4 mv=modelViewMatrix*vec4(position,1.0);gl_PointSize=aSize*uPixelRatio*(260.0/-mv.z)*(0.70+0.30*wave+0.90*glint);gl_Position=projectionMatrix*mv;}',fragmentShader:'uniform vec3 uColor;uniform float uOpacity;varying float vAlpha;void main(){vec2 p=gl_PointCoord-vec2(0.5);float d=length(p);if(d>0.5)discard;float core=smoothstep(0.5,0.0,d);float cross=max(smoothstep(0.12,0.0,abs(p.x))*smoothstep(0.5,0.0,abs(p.y)),smoothstep(0.12,0.0,abs(p.y))*smoothstep(0.5,0.0,abs(p.x)));float alpha=(core+cross*0.35)*vAlpha*uOpacity;gl_FragColor=vec4(uColor,alpha);}'});
  var layer=new THREE.Points(geo,mat);
  layer.userData={depth:depth,targetX:0,targetY:0,parallax:depth*3.4,baseZ:0};
  scene.add(layer);starLayers.push(layer);
}
/* 四层星空：密而小的底噪 + 中景 + 少量暖白 + 稀疏的大颗闪烁星 */
makeStars(1500,11,30,C_STAR_A,.090,.88,.035);
makeStars(760,9,27,C_STAR_B,.130,.86,.065);
makeStars(320,8,24,C_STAR_C,.180,.80,.095);
makeStars(90,7,22,C_STAR_D,.240,.95,.125);

function llv(lat,lng,rad){var la=THREE.MathUtils.degToRad(lat),lo=THREE.MathUtils.degToRad(lng);return new THREE.Vector3(rad*Math.cos(la)*Math.cos(lo),rad*Math.sin(la),-rad*Math.cos(la)*Math.sin(lo))}
var bermudaTitles=['波多黎各圣胡安','迈阿密（美国佛罗里达州）','英属百慕大群岛'];
function clearGeoFeatures(){while(geoFeatures.children.length){var obj=geoFeatures.children[0];geoFeatures.remove(obj);if(obj.geometry)obj.geometry.dispose();if(obj.material)obj.material.dispose()}}
function greatCirclePoints(a,b,radius){var va=llv(+a.lat,+a.lng,1).normalize(),vb=llv(+b.lat,+b.lng,1).normalize(),dot=Math.max(-1,Math.min(1,va.dot(vb))),angle=Math.acos(dot),steps=48,out=[];for(var i=0;i<=steps;i++){var t=i/steps,v;if(angle<.00001)v=va.clone();else{var s=Math.sin(angle);v=va.clone().multiplyScalar(Math.sin((1-t)*angle)/s).add(vb.clone().multiplyScalar(Math.sin(t*angle)/s)).normalize()}out.push(v.multiplyScalar(radius))}return out}
function drawBermudaTriangle(points){clearGeoFeatures();var byTitle={};(points||[]).forEach(function(p){byTitle[String(p.title||'').trim()]=p});var vertices=bermudaTitles.map(function(title){return byTitle[title]}).filter(Boolean);if(vertices.length!==3)return;var material=new THREE.LineBasicMaterial({color:C_CINNABAR,transparent:true,opacity:.92,depthTest:true,depthWrite:false});for(var i=0;i<3;i++){var line=new THREE.Line(new THREE.BufferGeometry().setFromPoints(greatCirclePoints(vertices[i],vertices[(i+1)%3],GLOBE_R*1.018)),material.clone());geoFeatures.add(line)}vertices.forEach(function(p){var dot=new THREE.Mesh(new THREE.SphereGeometry(.055,14,14),new THREE.MeshBasicMaterial({color:0xd4573c,transparent:true,opacity:.94,depthWrite:false}));dot.position.copy(llv(+p.lat,+p.lng,GLOBE_R*1.02));geoFeatures.add(dot)})}
function mobileRepresentativePoints(points){if(!isPhone)return points||[];var required={},buckets={},result=[];bermudaTitles.forEach(function(title){required[title]=true});(points||[]).forEach(function(p){var title=String(p.title||'').trim();if(required[title]){result.push(p);return}var lat=+p.lat,lng=+p.lng,key=Math.floor((lat+90)/10)+'_'+Math.floor((lng+180)/10),score=(+p.level||0)*10+(p.image_url?3:0)+(p.external_url?1:0);if(!buckets[key]||score>buckets[key].score)buckets[key]={p:p,score:score}});Object.keys(buckets).forEach(function(key){result.push(buckets[key].p)});return result}
function markerId(p){return String(p&&(p.id||p.title)||'')}
function holdMarker(p){heldMarkerPoint=p||null;heldMarkerId=markerId(p)}
function releaseMarkerHold(){
  /* 轮播选中的点位要一直保持高亮，别被 hover/tap 的收尾逻辑清掉 */
  if(carouselActiveId&&carouselList.length){
    var keep=null;for(var i=0;i<carouselList.length;i++){if(markerId(carouselList[i])===carouselActiveId){keep=carouselList[i];break}}
    if(keep){heldMarkerPoint=keep;heldMarkerId=carouselActiveId;return}
  }
  heldMarkerId='';heldMarkerPoint=null;
}
function clearMarkers(preserveHold){if(markerCycleTimer){clearTimeout(markerCycleTimer);markerCycleTimer=0}var now=performance.now();markers.forEach(function(x,index){x.userData.fadeStart=now+index*115;x.userData.fadeChildren=[];x.traverse(function(child){if(child.material){child.material.transparent=true;child.userData.fadeBase=child.material.opacity==null?1:child.material.opacity;x.userData.fadeChildren.push(child)}});fadingMarkers.push(x)});markers=[];clickables=[];markerEffects=[];activeExtraGroup=null;if(!preserveHold){hovered=null;hideMarkerTip()}}
function markerPriority(p){return(+p.level||0)*10+(p.image_url?3:0)+(p.external_url?1:0)}
function selectMarkerBatch(points){var all=mobileRepresentativePoints(points||[]),size=isPhone?phoneBatchSize:desktopBatchSize,required=bermudaTitles.map(function(title){return(all||[]).filter(function(p){return String(p.title||'').trim()===title})[0]}).filter(Boolean);if(heldMarkerPoint&&!required.some(function(p){return markerId(p)===heldMarkerId}))required.push(heldMarkerPoint);var pool=(all||[]).filter(function(p){return !required.some(function(x){return markerId(x)===markerId(p)})});pool.sort(function(a,b){return markerPriority(b)-markerPriority(a)});var offset=markerCycleIndex*size%(Math.max(pool.length,1));var batch=[];for(var i=0;i<Math.min(size,pool.length);i++)batch.push(pool[(offset+i)%pool.length]);return required.concat(batch)}
/* 点位不多时两端都直接铺满，别让「优先级前 N 个」把某一半地球留空；
   点位数超过上限才退回抽样 / 批量轮换。 */
var DISPLAY_ALL_MAX=60;
function computeDisplay(points){
  var all=points||[];
  if(all.length<=DISPLAY_ALL_MAX)return all.slice();
  if(!isPhone)return selectMarkerBatch(all);
  return mobileRepresentativePoints(all);
}
function scheduleMarkerCycle(points,getColor){var duration=2600;markerCycleTimer=setTimeout(function(){markerCycleIndex++;addMarkers(points,getColor)},duration)}

/* 造一个标记。返回 group，便于轮播临时补点。 */
function createMarker(p,color,index){
  var pos=llv(+p.lat,+p.lng,GLOBE_R*1.015),normal=pos.clone().normalize(),group=new THREE.Group();
  group.position.copy(pos);group.quaternion.setFromUnitVectors(new THREE.Vector3(0,1,0),normal);group.userData=p;
  if(isPhone){
    /* 手机端：贴面光环 + 细光柱 + 光点，全部加法混合，在夜墨底上干净发亮 */
    var ring=new THREE.Mesh(new THREE.RingGeometry(.048,.072,36),new THREE.MeshBasicMaterial({color:color,transparent:true,opacity:.52,side:THREE.DoubleSide,depthWrite:false,blending:THREE.AdditiveBlending}));
    ring.rotation.x=-Math.PI/2;ring.position.y=.006;group.add(ring);
    var beam=new THREE.Mesh(new THREE.CylinderGeometry(.0035,.0105,.145,6,1,true),new THREE.MeshBasicMaterial({color:color,transparent:true,opacity:.46,depthWrite:false,blending:THREE.AdditiveBlending}));
    beam.position.y=.072;group.add(beam);
    /* 核心用普通混合：加法混合会跟光环叠加后饱和成白色，把朱砂/赭金吃掉 */
    var core=new THREE.Mesh(new THREE.SphereGeometry(.024,12,12),new THREE.MeshBasicMaterial({color:color,transparent:true,opacity:.95,depthWrite:false}));
    core.position.y=.145;core.userData=p;group.add(core);
    var glow=new THREE.Mesh(new THREE.SphereGeometry(.055,12,12),new THREE.MeshBasicMaterial({color:color,transparent:true,opacity:.16,depthWrite:false,blending:THREE.AdditiveBlending}));
    glow.position.y=.145;group.add(glow);
    var hitArea=new THREE.Mesh(new THREE.SphereGeometry(.125,8,8),new THREE.MeshBasicMaterial({transparent:true,opacity:0,depthWrite:false}));
    hitArea.position.y=.1;hitArea.userData=p;group.add(hitArea);
    clickables.push(hitArea);
    globe.add(group);markers.push(group);
    markerEffects.push({group:group,core:core,glow:glow,ring:ring,beam:beam,phase:index*.73,data:p,mobile:true,born:performance.now()+index*90});
    return group;
  }
  /* 桌面端：旗杆 + 八面体 + 双环 + 光晕 */
  var stem=new THREE.Mesh(new THREE.CylinderGeometry(.008,.014,.15,8),new THREE.MeshBasicMaterial({color:color,transparent:true,opacity:.92,blending:THREE.AdditiveBlending}));
  stem.position.y=.075;group.add(stem);
  var core2=new THREE.Mesh(new THREE.OctahedronGeometry(.045,0),new THREE.MeshBasicMaterial({color:color}));
  core2.position.y=.17;core2.userData=p;group.add(core2);
  var hit2=new THREE.Mesh(new THREE.SphereGeometry(.13,10,10),new THREE.MeshBasicMaterial({transparent:true,opacity:0,depthWrite:false}));
  hit2.position.y=.17;hit2.userData=p;group.add(hit2);clickables.push(hit2);
  var ring1=new THREE.Mesh(new THREE.RingGeometry(.055,.07,32),new THREE.MeshBasicMaterial({color:color,transparent:true,opacity:.72,side:THREE.DoubleSide,depthWrite:false,blending:THREE.AdditiveBlending}));
  ring1.rotation.x=-Math.PI/2;ring1.position.y=.014;group.add(ring1);
  var ring2=new THREE.Mesh(new THREE.RingGeometry(.075,.085,32),new THREE.MeshBasicMaterial({color:color,transparent:true,opacity:.38,side:THREE.DoubleSide,depthWrite:false,blending:THREE.AdditiveBlending}));
  ring2.rotation.x=-Math.PI/2;ring2.position.y=.012;group.add(ring2);
  var glow2=new THREE.Mesh(new THREE.SphereGeometry(.075,12,12),new THREE.MeshBasicMaterial({color:color,transparent:true,opacity:.17,depthWrite:false,blending:THREE.AdditiveBlending}));
  glow2.position.y=.17;group.add(glow2);
  globe.add(group);markers.push(group);
  markerEffects.push({group:group,core:core2,glow:glow2,r1:ring1,r2:ring2,phase:index*.73,data:p,mobile:false});
  return group;
}

function addMarkers(points,getColor){
  lastPoints=points||[];lastColorFn=getColor||null;
  var keepId=(carouselList[carouselIdx]?markerId(carouselList[carouselIdx]):'');
  clearMarkers(true);
  drawBermudaTriangle(window.getAllPoints?window.getAllPoints():points);
  var display=computeDisplay(lastPoints);
  var colorOf=function(p){return getColor?getColor(p):C_BRASS_L};
  display.forEach(function(p,index){createMarker(p,colorOf(p),index)});

  if(isPhone){
    /* 手机端不走批量轮换，改为轮播卡片驱动 */
    carouselList=display.slice();
    var ni=-1;
    if(keepId){for(var i=0;i<carouselList.length;i++){if(markerId(carouselList[i])===keepId){ni=i;break}}}
    carouselIdx=ni>=0?ni:(carouselList.length?0:-1);
    buildMobileUI();
    if(carouselIdx>=0){renderCard(carouselList[carouselIdx]);carouselActiveId=markerId(carouselList[carouselIdx]);holdMarker(carouselList[carouselIdx]);carouselT0=performance.now()}
    else{carouselActiveId='';renderCard(null)}
  }else{
    carouselList=[];carouselActiveId='';
    scheduleMarkerCycle(points,getColor);
  }
}

/* ---------- 交互 ---------- */
var canvas=renderer.domElement;
canvas.addEventListener('mousedown',function(e){if(transitioning)return;drag=true;moved=false;auto=false;turn=null;last={x:e.clientX,y:e.clientY}});
window.addEventListener('mouseup',function(){drag=false});
window.addEventListener('mousemove',function(e){
  if(drag&&!transitioning){
    var dx=e.clientX-last.x,dy=e.clientY-last.y;
    if(Math.abs(dx)+Math.abs(dy)>2)moved=true;
    ry+=dx*.004;rx+=dy*.004;
    skyParallax.targetX=Math.max(-1,Math.min(1,dx*.025));skyParallax.targetY=Math.max(-1,Math.min(1,dy*.025));
    rx=Math.max(-1.25,Math.min(1.25,rx));last={x:e.clientX,y:e.clientY};hideMarkerTip();return;
  }
  if(!transitioning)updateHover(e);
});
canvas.addEventListener('mouseleave',hideMarkerTip);
canvas.addEventListener('wheel',function(e){
  e.preventDefault();if(transitioning)return;
  if(e.deltaY<0){
    zoomIntent+=Math.min(180,Math.abs(e.deltaY));
    distance=Math.max(minDist,distance+e.deltaY*.008);
    if(!isPhone&&distance<=minDist*1.02&&zoomIntent>260)transitionToMap();
  }else{
    zoomIntent=Math.max(0,zoomIntent-Math.abs(e.deltaY));
    distance=Math.min(maxDist,distance+e.deltaY*.008);
  }
  syncZoomUI();
},{passive:false});

var touchMode='',touchStart={x:0,y:0},pinchStart=0,pinchDistance=distance,touchMoved=false;
function touchGap(t){var dx=t[0].clientX-t[1].clientX,dy=t[0].clientY-t[1].clientY;return Math.sqrt(dx*dx+dy*dy)}
canvas.addEventListener('touchstart',function(e){
  if(transitioning)return;e.preventDefault();
  auto=false;turn=null;touchMoved=false;
  if(e.touches.length===1){touchMode='rotate';touchStart={x:e.touches[0].clientX,y:e.touches[0].clientY}}
  else if(e.touches.length===2){touchMode='pinch';pinchStart=touchGap(e.touches);pinchDistance=distance}
},{passive:false});
canvas.addEventListener('touchmove',function(e){
  if(transitioning)return;e.preventDefault();
  if(touchMode==='rotate'&&e.touches.length===1){
    var t=e.touches[0],dx=t.clientX-touchStart.x,dy=t.clientY-touchStart.y;
    if(Math.abs(dx)+Math.abs(dy)>3)touchMoved=true;
    ry+=dx*.006;rx+=dy*.006;
    skyParallax.targetX=Math.max(-1,Math.min(1,dx*.035));skyParallax.targetY=Math.max(-1,Math.min(1,dy*.035));
    rx=Math.max(-1.25,Math.min(1.25,rx));touchStart={x:t.clientX,y:t.clientY};
  }else if(e.touches.length===2){
    touchMode='pinch';touchMoved=true;
    var gap=touchGap(e.touches),ratio=pinchStart/Math.max(gap,20);
    distance=Math.max(minDist,Math.min(maxDist,pinchDistance*ratio));
    syncZoomUI();
    if(!isPhone&&distance<=minDist*1.02&&gap>pinchStart*1.28)transitionToMap();
  }
  if(touchMoved)carouselHoldUntil=performance.now()+9000;   /* 用户在看：轮播先别急着走 */
},{passive:false});
function showPhoneMarkerName(p,t){
  hovered=p;holdMarker(p);
  var tip=document.getElementById('globeMarkerTip');
  if(!tip){tip=document.createElement('div');tip.id='globeMarkerTip';tip.className='globe-marker-tip';el.appendChild(tip)}
  tip.innerHTML='<i></i><b>'+escapeHtml(p.title||'未知地点')+'</b><small>'+escapeHtml([p.country,p.province,p.city].filter(Boolean).join(' · ')||'未知地区')+'</small><small>再次点击查看地点详情</small>';
  var rect=canvas.getBoundingClientRect();
  tip.style.left=Math.max(10,Math.min(rect.width-190,t.clientX-rect.left-78))+'px';
  tip.style.top=Math.max(54,t.clientY-rect.top-72)+'px';
  tip.classList.add('show');
}
canvas.addEventListener('touchend',function(e){
  e.preventDefault();
  if(e.touches.length===0){
    touchMode='';
    if(!touchMoved&&e.changedTouches.length){
      var t=e.changedTouches[0],fake={clientX:t.clientX,clientY:t.clientY},hit=visibleHit(fake);
      if(hit){
        var p=hit.object.userData,id=String(p.id||p.title||'');
        if(isPhone&&phoneSelectedMarkerId!==id){phoneSelectedMarkerId=id;showPhoneMarkerName(p,t)}
        else{phoneSelectedMarkerId='';openOnMap(p)}
      }else if(isPhone){phoneSelectedMarkerId='';hideMarkerTip()}
    }
  }else if(e.touches.length===1){touchMode='rotate';touchStart={x:e.touches[0].clientX,y:e.touches[0].clientY}}
},{passive:false});
canvas.addEventListener('click',function(e){
  if(moved)return;
  var rect=canvas.getBoundingClientRect();
  mouse.x=(e.clientX-rect.left)/rect.width*2-1;mouse.y=-(e.clientY-rect.top)/rect.height*2+1;
  ray.setFromCamera(mouse,camera);var hit=ray.intersectObjects(clickables)[0];
  if(hit)openOnMap(hit.object.userData);
});
function visibleHit(e){var rect=canvas.getBoundingClientRect();mouse.x=(e.clientX-rect.left)/rect.width*2-1;mouse.y=-(e.clientY-rect.top)/rect.height*2+1;ray.setFromCamera(mouse,camera);var markerHit=ray.intersectObjects(clickables)[0],earthHit=ray.intersectObject(earth)[0];return markerHit&&(!earthHit||markerHit.distance<earthHit.distance+.03)?markerHit:null}
function updateHover(e){
  var hit=visibleHit(e);if(!hit){hideMarkerTip();return}
  hovered=hit.object.userData;holdMarker(hovered);canvas.style.cursor='pointer';
  var tip=document.getElementById('globeMarkerTip');
  if(!tip){tip=document.createElement('div');tip.id='globeMarkerTip';tip.className='globe-marker-tip';el.appendChild(tip)}
  tip.innerHTML='<i></i><b>'+escapeHtml(hovered.title||'未知地点')+'</b><small>'+escapeHtml(hovered.country||'未知地区')+'</small><small>坐标 '+Number(hovered.lat).toFixed(6)+', '+Number(hovered.lng).toFixed(6)+'</small>';
  tip.style.left=(e.clientX+16)+'px';tip.style.top=(e.clientY-12)+'px';tip.classList.add('show');
}
function hideMarkerTip(){releaseMarkerHold();hovered=null;canvas.style.cursor=drag?'grabbing':'grab';var tip=document.getElementById('globeMarkerTip');if(tip)tip.classList.remove('show')}
function escapeHtml(s){return String(s==null?'':s).replace(/[&<>"']/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})}
function openOnMap(p){releaseMarkerHold();transitionToMap(p)}
function facingCenter(){globe.updateMatrixWorld(true);var q=globe.quaternion.clone().invert(),v=new THREE.Vector3(0,0,1).applyQuaternion(q).normalize();return{lat:THREE.MathUtils.radToDeg(Math.asin(v.y)),lng:THREE.MathUtils.radToDeg(Math.atan2(-v.z,v.x))}}

/* 让某个经纬度转到正对镜头。globe 的欧拉顺序是 XYZ（R = Rx·Ry），
   所以 rx 取纬度、ry 取 atan2(-x, z) 即可把点对到 +Z 方向。 */
function facePoint(lat,lng){
  var la=THREE.MathUtils.degToRad(lat),lo=THREE.MathUtils.degToRad(lng);
  var vx=Math.cos(la)*Math.cos(lo),vz=-Math.cos(la)*Math.sin(lo);
  return{rx:Math.max(-1.25,Math.min(1.25,la)),ry:Math.atan2(-vx,vz)};
}
function turnTo(targetRx,targetRy,dur){
  var from=ry,d=targetRy-from;
  d=((d+Math.PI)%(Math.PI*2)+Math.PI*2)%(Math.PI*2)-Math.PI;   /* 走最短弧 */
  turn={fromRx:rx,fromRy:from,toRx:targetRx,toRy:from+d,t0:performance.now(),dur:dur||1000};
}

/* ---------- 手机端 UI：轮播卡片 + 滑动缩放条 ---------- */
function buildMobileUI(){
  if(!isPhone||MOBILE_UI_BUILT)return;
  MOBILE_UI_BUILT=true;
  /* 轮播卡片 */
  carouselEl=document.createElement('div');carouselEl.className='globe-carousel';
  carouselEl.innerHTML='<div class="gc-inner">'
    +'<div class="gc-thumb"><span class="gc-seal"></span></div>'
    +'<div class="gc-main">'
    +'<div class="gc-meta"><span class="gc-idx"></span><span class="gc-cat"></span></div>'
    +'<b class="gc-title"></b><small class="gc-sub"></small>'
    +'</div>'
    +'<div class="gc-ctrl">'
    +'<button type="button" class="gc-btn gc-prev" aria-label="上一个">‹</button>'
    +'<button type="button" class="gc-btn gc-play" aria-label="暂停轮播"><i></i></button>'
    +'<button type="button" class="gc-btn gc-next" aria-label="下一个">›</button>'
    +'</div></div>'
    +'<div class="gc-prog"><i></i></div>';
  el.appendChild(carouselEl);
  carouselCard=carouselEl.querySelector('.gc-inner');
  gcThumb=carouselEl.querySelector('.gc-thumb');gcSeal=carouselEl.querySelector('.gc-seal');
  gcIdx=carouselEl.querySelector('.gc-idx');gcCat=carouselEl.querySelector('.gc-cat');
  gcTitle=carouselEl.querySelector('.gc-title');gcSub=carouselEl.querySelector('.gc-sub');
  gcProg=carouselEl.querySelector('.gc-prog>i');gcPlay=carouselEl.querySelector('.gc-play');
  carouselEl.querySelector('.gc-prev').addEventListener('click',function(e){e.stopPropagation();carouselStep(-1)});
  carouselEl.querySelector('.gc-next').addEventListener('click',function(e){e.stopPropagation();carouselStep(1)});
  gcPlay.addEventListener('click',function(e){
    e.stopPropagation();carouselPaused=!carouselPaused;carouselT0=performance.now();
    gcPlay.classList.toggle('paused',carouselPaused);
    gcPlay.setAttribute('aria-label',carouselPaused?'继续轮播':'暂停轮播');
    carouselEl.classList.toggle('paused',carouselPaused);
  });
  carouselCard.addEventListener('click',function(){var p=carouselList[carouselIdx];if(p)openOnMap(p)});
  /* 卡片上左右滑动切换 */
  var sx=0,sy=0,sw=false;
  carouselCard.addEventListener('touchstart',function(e){
    if(e.touches.length!==1)return;sx=e.touches[0].clientX;sy=e.touches[0].clientY;sw=true;
  },{passive:true});
  carouselCard.addEventListener('touchend',function(e){
    if(!sw)return;sw=false;var t=e.changedTouches[0];if(!t)return;
    var dx=t.clientX-sx,dy=t.clientY-sy;
    if(Math.abs(dx)>42&&Math.abs(dx)>Math.abs(dy)*1.4)carouselStep(dx<0?1:-1);
  },{passive:true});

  /* 竖向滑动缩放条 */
  zoomEl=document.createElement('div');zoomEl.className='globe-zoom';
  zoomEl.innerHTML='<button type="button" class="gz-btn gz-in" aria-label="放大">+</button>'
    +'<div class="gz-track"><i></i><b></b></div>'
    +'<button type="button" class="gz-btn gz-out" aria-label="缩小">−</button>';
  el.appendChild(zoomEl);
  gzTrack=zoomEl.querySelector('.gz-track');gzFill=zoomEl.querySelector('.gz-track>i');gzKnob=zoomEl.querySelector('.gz-track>b');
  zoomEl.querySelector('.gz-in').addEventListener('click',function(e){e.stopPropagation();zoomBy(-.34)});
  zoomEl.querySelector('.gz-out').addEventListener('click',function(e){e.stopPropagation();zoomBy(.34)});
  var dragging=false;
  function setFromEvent(ev){
    var r=gzTrack.getBoundingClientRect(),y=(ev.touches?ev.touches[0].clientY:ev.clientY)-r.top;
    var t=Math.max(0,Math.min(1,y/Math.max(1,r.height)));      /* 0=顶=最近 */
    distance=minDist+(maxDist-minDist)*t;syncZoomUI();
  }
  gzTrack.addEventListener('touchstart',function(e){e.preventDefault();e.stopPropagation();dragging=true;setFromEvent(e)},{passive:false});
  gzTrack.addEventListener('touchmove',function(e){e.preventDefault();e.stopPropagation();if(dragging)setFromEvent(e)},{passive:false});
  gzTrack.addEventListener('touchend',function(e){e.stopPropagation();dragging=false},{passive:true});
  gzTrack.addEventListener('mousedown',function(e){e.preventDefault();e.stopPropagation();dragging=true;setFromEvent(e)});
  window.addEventListener('mousemove',function(e){if(dragging)setFromEvent(e)});
  window.addEventListener('mouseup',function(){dragging=false});

  /* 顶部提示，几秒后隐去 */
  hintEl=document.createElement('div');hintEl.className='globe-hint';
  hintEl.textContent='拖拽旋转 · 双指缩放 · 下滑卡片切换档案';
  el.appendChild(hintEl);
  setTimeout(function(){if(hintEl)hintEl.classList.add('hide')},5600);
  syncZoomUI();
}
function zoomBy(delta){distance=Math.max(minDist,Math.min(maxDist,distance+delta*(maxDist-minDist)));syncZoomUI()}
function syncZoomUI(){
  if(!gzKnob)return;
  var t=(distance-minDist)/Math.max(.0001,maxDist-minDist);
  t=Math.max(0,Math.min(1,t));
  gzKnob.style.top=(t*100)+'%';     /* 顶端=最近（放大），底端=最远 */
}
function thumbOf(p){
  if(!p)return'';
  if(p.image_url)return p.image_url;
  if(p.cover)return p.cover;
  var im=p.images;
  if(Array.isArray(im)&&im.length)return im[0];
  if(typeof im==='string'&&im){
    try{var a=JSON.parse(im);if(Array.isArray(a)&&a.length)return a[0]}catch(e){}
    if(im.indexOf(',')>0)return im.split(',')[0].trim();
    if(im.charAt(0)==='/')return im;
  }
  return'';
}
function renderCard(p){
  if(!carouselEl)return;
  if(!p){carouselEl.classList.add('empty');return}
  carouselEl.classList.remove('empty');
  var n=carouselList.length,i=carouselIdx+1;
  if(gcIdx)gcIdx.textContent=(i<10?'0':'')+i+' / '+(n<10?'0':'')+n;
  var cat=(window.__catName?window.__catName(p.category):'')||p.category_name||'';
  if(gcCat){gcCat.textContent=cat;gcCat.style.display=cat?'':'none'}
  if(gcTitle)gcTitle.textContent=p.title||'未知地点';
  if(gcSub)gcSub.textContent=[p.country,p.province,p.city].filter(Boolean).join(' · ')||'未知地区';
  var src=thumbOf(p);
  if(src){
    if(gcThumb.dataset.src!==src){
      gcThumb.dataset.src=src;
      gcThumb.style.backgroundImage='url("'+String(src).replace(/"/g,'%22')+'")';
    }
    gcThumb.classList.add('has-img');
  }else{
    gcThumb.classList.remove('has-img');gcThumb.style.backgroundImage='';gcThumb.dataset.src='';
  }
  /* 无图时盖一枚分类印章，比重复序号更有档案味 */
  if(gcSeal)gcSeal.textContent=cat?cat.charAt(0):'档';
}
function carouselStep(dir){if(!carouselList.length)return;carouselShow(carouselIdx+dir,true)}
function carouselShow(i,userDriven){
  if(!carouselList.length)return;
  var n=carouselList.length;
  carouselIdx=((i%n)+n)%n;
  var p=carouselList[carouselIdx];
  carouselT0=performance.now();
  renderCard(p);
  carouselActiveId=markerId(p);holdMarker(p);
  /* 选中点如果不在当前铺开的标记里，补一个临时标记，切走时再撤掉 */
  var exists=false;
  for(var k=0;k<markers.length;k++){if(markerId(markers[k].userData)===carouselActiveId){exists=true;break}}
  if(activeExtraGroup){globe.remove(activeExtraGroup);for(var c=0;c<clickables.length;c++){if(clickables[c].parent===activeExtraGroup){clickables.splice(c,1);break}}activeExtraGroup=null}
  if(!exists)activeExtraGroup=createMarker(p,lastColorFn?lastColorFn(p):C_BRASS_L,0);
  var f=facePoint(+p.lat,+p.lng);
  turnTo(f.rx,f.ry,userDriven?700:1150);
}
function startCarousel(){
  if(!isPhone||!carouselList.length)return;
  carouselPaused=false;carouselT0=performance.now();
  if(gcPlay){gcPlay.classList.remove('paused');gcPlay.setAttribute('aria-label','暂停轮播')}
  if(carouselEl)carouselEl.classList.remove('paused');
  if(carouselEl)carouselEl.classList.remove('empty');
  if(carouselIdx<0)carouselIdx=0;
  carouselShow(carouselIdx,false);
}
function stopCarousel(){if(carouselEl)carouselEl.classList.add('empty')}

/* ---------- 视图切换 ---------- */
function transitionToMap(point,preserveMapView){
  if(transitioning)return;stopGlobeOnline();stopCarousel();
  transitioning=true;auto=false;drag=false;turn=null;
  var center,ll;
  if(!preserveMapView){
    center=point?{lat:+point.lat,lng:+point.lng}:facingCenter();
    ll=window.toActiveCrs?window.toActiveCrs(center.lat,center.lng):[center.lat,center.lng];
    if(window.map){window.map.stop();window.map.setView(ll,point?12:5,{animate:false});window.map.invalidateSize()}
  }
  document.body.classList.remove('globe-mode');el.classList.add('globe-transition');
  document.querySelectorAll('#viewToggle button').forEach(function(btn){btn.classList.toggle('active',btn.getAttribute('data-view')==='flat')});
  var start=performance.now(),from=distance;
  function dive(now){
    var t=Math.min(1,(now-start)/680),ease=1-Math.pow(1-t,3);
    distance=from+(5.95-from)*ease;
    if(t<1)requestAnimationFrame(dive);
    else{
      el.classList.remove('active','globe-transition');
      distance=fitDist;zoomIntent=0;transitioning=false;
      localStorage.setItem('spooky_view','flat');
      if(window.map){window.map.invalidateSize();if(!preserveMapView)window.map.flyTo(ll,point?12:7,{duration:.75})}
      if(point&&window.openProfile)setTimeout(function(){window.openProfile(point,false)},320);
    }
  }
  requestAnimationFrame(dive);
}
function switchView(view){
  var isGlobe=view==='globe';
  if(!isGlobe&&el.classList.contains('active')){transitionToMap(null,true);return}
  document.body.classList.toggle('globe-mode',isGlobe);
  el.classList.toggle('active',isGlobe);
  document.querySelectorAll('#viewToggle button').forEach(function(btn){btn.classList.toggle('active',btn.getAttribute('data-view')===view)});
  if(isGlobe){
    resize();distance=fitDist;
    rx=isPhone?.26:0;ry=isPhone?-.5:ry;
    phoneSelectedMarkerId='';zoomIntent=0;
    auto=!isPhone;                     /* 手机端不自转 */
    turn=null;carouselHoldUntil=0;
    if(isPhone){buildMobileUI();startCarousel()}
    startGlobeOnline();
  }else{
    stopGlobeOnline();stopCarousel();
    if(window.map)setTimeout(function(){window.map.invalidateSize()},80);
  }
  localStorage.setItem('spooky_view',isGlobe?'globe':'flat');
}
var globeOnlineTimer=0;
function updateGlobeOnline(){
  var onlineEl=document.getElementById('globeOnlineCount');
  if(!onlineEl){onlineEl=document.createElement('div');onlineEl.id='globeOnlineCount';onlineEl.style.cssText='position:absolute;top:28px;left:34px;z-index:2;color:#a08a5c;font-size:10px;letter-spacing:3px;opacity:.62';el.appendChild(onlineEl)}
  fetch('api/visit.php?action=get_online&_='+Date.now(),{cache:'no-store',headers:{'Cache-Control':'no-cache'}})
    .then(function(r){return r.json()})
    .then(function(j){var d=j.data||j;if(onlineEl&&d.online_visitors!==undefined)onlineEl.textContent='在线 '+((+d.online_visitors||0)+(+d.online_admins||0))+' 人'})
    .catch(function(){});
}
function startGlobeOnline(){clearInterval(globeOnlineTimer);updateGlobeOnline();globeOnlineTimer=setInterval(updateGlobeOnline,5000)}
function stopGlobeOnline(){clearInterval(globeOnlineTimer);globeOnlineTimer=0}
document.querySelectorAll('#viewToggle button').forEach(function(btn){btn.onclick=function(){switchView(btn.getAttribute('data-view'))}});

window.__globe={
  resize:resize,addMarkers:addMarkers,carouselStep:carouselStep,carouselShow:carouselShow,
  stats:function(){return{
    isPhone:isPhone,auto:auto,distance:Math.round(distance*100)/100,
    fitDist:Math.round(fitDist*100)/100,minDist:Math.round(minDist*100)/100,maxDist:Math.round(maxDist*100)/100,
    markers:markers.length,carousel:carouselList.length,carouselIdx:carouselIdx,
    stars:starLayers.length,turning:!!turn,active:el.classList.contains('active')
  }}
};
window.updateGlobeMarkers=addMarkers;
window.switchGlobeView=switchView;
window.getFilteredPoints=function(){return window.__globePoints||[]};

function animate(now){
  requestAnimationFrame(animate);
  var time=now||performance.now();

  fadingMarkers=fadingMarkers.filter(function(group){
    var alpha=1-Math.max(0,Math.min(1,(time-(group.userData.fadeStart||time))/620));
    group.traverse(function(child){if(child.material&&child.userData.fadeBase!=null)child.material.opacity=child.userData.fadeBase*alpha});
    if(alpha<=0){globe.remove(group);group.traverse(function(child){if(child.geometry)child.geometry.dispose();if(child.material)child.material.dispose()});return false}
    return true;
  });

  updateActiveLatitude(time);

  /* 平滑转向（轮播 / 定点） */
  if(turn){
    var tt=Math.min(1,(time-turn.t0)/turn.dur);
    var te=tt<.5?4*tt*tt*tt:1-Math.pow(-2*tt+2,3)/2;
    rx=turn.fromRx+(turn.toRx-turn.fromRx)*te;
    ry=turn.fromRy+(turn.toRy-turn.fromRy)*te;
    if(tt>=1)turn=null;
  }else if(auto&&!transitioning){
    ry+=.0009;                        /* 只有桌面端会走到这里 */
  }

  globe.rotation.x=rx;globe.rotation.y=ry;
  skyParallax.targetX*=.9;skyParallax.targetY*=.9;
  skyParallax.x+=(skyParallax.targetX-skyParallax.x)*.12;
  skyParallax.y+=(skyParallax.targetY-skyParallax.y)*.12;
  camera.position.set(0,0,distance);camera.lookAt(0,0,0);

  /* 星空整体随镜头推移，缩放时密度与亮度保持一致 */
  var zoomK=distance/STAR_BASE;
  starLayers.forEach(function(layer){
    var d=layer.userData;
    d.targetX=skyParallax.x*d.parallax;d.targetY=-skyParallax.y*d.parallax;
    layer.position.x+=(d.targetX-layer.position.x)*.11;
    layer.position.y+=(d.targetY-layer.position.y)*.11;
    layer.scale.setScalar(zoomK);
    layer.position.z=distance-STAR_BASE;
    layer.rotation.set(0,0,0);
    layer.material.uniforms.uTime.value=time*.001;
    layer.material.uniforms.uPixelRatio.value=Math.min(window.devicePixelRatio||1,1.75);
  });

  markerEffects.forEach(function(m){
    var t=time*.0022+m.phase;
    if(m.mobile){
      var age=time-m.born,active=(carouselActiveId&&carouselActiveId===markerId(m.data));
      var fadeIn=Math.max(0,Math.min(1,age/460));
      var pulse=1+Math.sin(t*1.55)*(active?.20:.06);
      var s=(active?1.55:1)*pulse*fadeIn;
      m.core.scale.set(s,s,s);
      m.core.material.opacity=(active?.98:.80)*fadeIn;
      if(m.glow){var gs=(active?1.5:1)*fadeIn;m.glow.scale.set(gs,gs,gs);m.glow.material.opacity=(active?.38:.17)*fadeIn}
      if(m.ring){
        if(active){
          var rp=(time/1500)%1;                       /* 雷达式扩散 */
          var rs=fadeIn*(1.2+rp*2.1);m.ring.scale.set(rs,rs,rs);
          m.ring.material.opacity=(1-rp)*.95*fadeIn;
        }else{
          m.ring.scale.set(fadeIn,fadeIn,fadeIn);
          m.ring.material.opacity=.40*fadeIn;
        }
      }
      if(m.beam)m.beam.material.opacity=(active?.72:.40)*fadeIn;
      return;
    }
    var pulseD=1+Math.sin(t*1.35)*.13;
    m.core.scale.set(pulseD,pulseD,pulseD);
    var s1=1.05+(Math.sin(t)+1)*.65,s2=1.15+(Math.sin(t+2.1)+1)*.9;
    m.r1.scale.set(s1,s1,s1);m.r1.material.opacity=.62*(1-(s1-1.05)/1.3);
    m.r2.scale.set(s2,s2,s2);m.r2.material.opacity=.32*(1-(s2-1.15)/1.8);
    m.glow.scale.set(1.1+Math.sin(t)*.22,1.1+Math.sin(t)*.22,1.1+Math.sin(t)*.22);
  });

  guideLabels.forEach(function(label){
    var world=label.getWorldPosition(new THREE.Vector3()),dir=world.clone().normalize(),toCamera=camera.position.clone().sub(world).normalize();
    label.material.opacity=dir.dot(toCamera)>.08?1:0;
  });

  /* 轮播推进 */
  if(isPhone&&carouselEl&&carouselList.length>1){
    var running=!carouselPaused&&time>=carouselHoldUntil;
    if(running){
      var elapsed=time-carouselT0;
      if(elapsed>=carouselDur){carouselT0=time;carouselShow(carouselIdx+1,false)}
      else if(gcProg)gcProg.style.width=Math.min(100,elapsed/carouselDur*100)+'%';
    }
  }

  renderer.render(scene,camera);
}
animate();

function syncMarkers(){if(window.getFilteredPoints)addMarkers(window.getFilteredPoints(),function(p){return +p.level>=5?C_CINNABAR:C_BRASS_L})}
setTimeout(syncMarkers,500);setTimeout(syncMarkers,1800);

/* v6.1.6.59：访客每次打开首页一律停在平面地图。
   原逻辑会读取 localStorage.spooky_view 自动恢复地球仪，导致上次点过地球仪的老访客
   再次进站直接落在 3D 视图。这里改为启动时清掉该记忆并强制平面，地球仪仍可手动切换。 */
try{localStorage.setItem('spooky_view','flat')}catch(e){}
document.body.classList.remove('globe-mode');
el.classList.remove('active','globe-transition');
document.querySelectorAll('#viewToggle button').forEach(function(btn){btn.classList.toggle('active',btn.getAttribute('data-view')==='flat')});
})();
