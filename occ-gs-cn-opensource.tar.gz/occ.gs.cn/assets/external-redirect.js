(function(){
'use strict';
function clean(v){return String(v==null?'':v).trim()}
function config(){return window.__externalRedirectConfig||{whitelist:'',redirect:'go.php'}}
function hosts(value){var set={};String(value||'').split(/[\r\n,]+/).forEach(function(row){var host=clean(row).toLowerCase().replace(/^https?:\/\//,'').replace(/\/.*$/,'').replace(/^\./,'');if(/^[a-z0-9.-]+(?::\d+)?$/i.test(host))set[host]=true});return set}
function shouldRedirect(raw){var url;try{url=new URL(raw,location.href)}catch(e){return false}if(url.protocol!=='http:'&&url.protocol!=='https:')return false;if(url.origin===location.origin)return false;var allowed=hosts(config().whitelist),host=url.host.toLowerCase(),name=url.hostname.toLowerCase();return !(allowed[host]||allowed[name])}
function redirect(raw){var base=config().redirect||'go.php',from=location.href;try{if(window.__saveMapReturnState)window.__saveMapReturnState()}catch(e){}location.href=base+'?url='+encodeURIComponent(raw)+'&return='+encodeURIComponent(from)}
document.addEventListener('click',function(event){if(event.defaultPrevented||event.button!==0||event.metaKey||event.ctrlKey||event.shiftKey||event.altKey)return;var anchor=event.target.closest&&event.target.closest('a[href]');if(!anchor||anchor.hasAttribute('download')||anchor.dataset.noRedirect==='1')return;var raw=anchor.getAttribute('href');if(!raw||raw.charAt(0)==='#'||/^javascript:/i.test(raw)||!shouldRedirect(raw))return;event.preventDefault();redirect(new URL(raw,location.href).href)},true);
window.openExternalWithRedirect=function(raw){if(shouldRedirect(raw)){redirect(new URL(raw,location.href).href);return false}window.open(raw,'_blank','noopener');return false};
})();