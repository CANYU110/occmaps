(function(){
'use strict';
function enhance(){
 var form=document.getElementById('mapSettingsForm');
 if(!form)return;
 var select=form.querySelector('[name="default_map"]');
 if(select&&!select.querySelector('option[value="tencent"]')){
  var option=document.createElement('option');
  option.value='tencent';
  option.textContent='腾讯标准';
  select.appendChild(option);
 }
}
new MutationObserver(enhance).observe(document.body,{childList:true,subtree:true});
setInterval(enhance,600);
enhance();
})();
