(function(){
'use strict';
function clean(v){return String(v==null?'':v).trim()}
function esc(v){return String(v==null?'':v).replace(/[&<>"']/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})}
function asset(v,fallback){v=clean(v).replace(/\\/g,'/');if(/^https?:\/\/[^\s<>"']+$/i.test(v)||/^(?:assets|uploads)\/[a-zA-Z0-9_./-]+$/.test(v))return v||fallback;return fallback}
function href(v){v=clean(v);if(!v||/[<>"']/.test(v)||/^javascript:/i.test(v))return'';if(/^https?:\/\//i.test(v)||v.charAt(0)==='#'||v.charAt(0)==='/')return v;while(v.indexOf('../')===0)v=v.slice(3);return v}
function menu(value){return String(value||'').split(/\r?\n/).slice(0,8).map(function(line){var i=line.indexOf('|'),label=clean(i<0?'':line.slice(0,i)),url=href(i<0?'':line.slice(i+1));if(!label||!url)return'';return'<a href="'+esc(url)+'"'+(/^https?:\/\//i.test(url)?' target="_blank" rel="noopener"':'')+'>'+esc(label)+'</a>'}).join('')}
function links(value){return String(value||'').split(/\r?\n/).slice(0,10).map(function(line){var i=line.indexOf('|'),label=clean(i<0?'':line.slice(0,i)),url=href(i<0?'':line.slice(i+1));if(!label||!url)return'';return'<a href="'+esc(url)+'"'+(/^https?:\/\//i.test(url)?' target="_blank" rel="noopener"':'')+'>'+esc(label)+'</a>'}).join('')}
window.renderPlaceShell=function(settings,categories){
 settings=settings||{};categories=Array.isArray(categories)?categories:[];
 var headerLogo=asset(settings.favicon_url,'assets/site-logo.webp?v=6.1.7.47'),footerLogo=asset(settings.footer_logo_url,'assets/footer-default-logo.svg'),brand=document.getElementById('detailBrand'),brandImg=document.getElementById('detailBrandLogo'),nav=document.getElementById('detailMenu'),footer=document.getElementById('detailFooter');
 if(brandImg){brandImg.src=headerLogo;brandImg.alt=(settings.site_name||'网站')+' Logo'}
 if(brand)brand.href='./';
 if(nav)nav.innerHTML=menu(settings.browse_header_menu);
 if(!footer)return;
 var year=new Date().getFullYear(),copyright=clean(settings.copyright_text)||('© '+year+' 全球灵异地点地图。版权所有。'),categoryLinks=String(settings.footer_category_mode||'auto')==='auto'?categories.slice(0,8).map(function(c){return'<a href="types/?category='+encodeURIComponent(c.slug)+'">'+esc(c.name)+'</a>'}).join(''):links(settings.footer_category_links),bg=asset(settings.footer_bg_image,'');
 footer.style.backgroundColor=settings.footer_bg_color||'#12140f';footer.style.setProperty('--detail-footer-line',settings.footer_divider_color||'#31352c');footer.style.setProperty('--detail-footer-heading',settings.footer_heading_color||'#b8813f');footer.style.setProperty('--detail-footer-link',settings.footer_link_color||'#8b8878');footer.style.backgroundImage=bg?'linear-gradient(rgba(12,14,20,.88),rgba(12,14,20,.94)),url("'+esc(bg)+'")':'';
 footer.style.backgroundSize='cover';footer.style.backgroundPosition='center';footer.style.backgroundRepeat='no-repeat';
 if(String(settings.footer_enabled||'1')==='0'){footer.className='detail-footer compact';footer.textContent=copyright;return}
 footer.className='detail-footer';footer.innerHTML='<div class="detail-footer-main"><section class="detail-footer-brand"><div><img src="'+esc(footerLogo)+'" alt="'+esc(settings.site_name||'网站 Logo')+'"><h2>'+esc(settings.footer_brand_title||settings.site_name||'全球灵异地点地图')+'</h2></div><p>'+esc(settings.footer_brand_intro||'收录民间传说、地方志、都市怪谈与实地探访记录。')+'</p></section><nav><h3>'+esc(settings.footer_explore_title||'探索')+'</h3>'+links(settings.footer_explore_links)+'</nav><nav><h3>'+esc(settings.footer_category_title||'类别')+'</h3>'+categoryLinks+'</nav><nav><h3>'+esc(settings.footer_site_title||'关于本站')+'</h3>'+links(settings.footer_site_links)+'</nav></div><div class="detail-footer-bottom"><span>'+esc(copyright)+'</span><nav>'+links(settings.footer_bottom_links)+'</nav></div>';
};
})();