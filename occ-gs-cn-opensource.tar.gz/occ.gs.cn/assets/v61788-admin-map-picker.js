(function(){
'use strict';
var enhanced=new WeakSet(),mapConfig=null;
function $q(s,r){return(r||document).querySelector(s)}
function isMainland(lat,lng){return typeof ctInAmapCoverage==='function'&&ctInAmapCoverage(+lng,+lat)}
function toGcj(lat,lng){var p=wgs84ToGcj02(+lng,+lat,true);return[p[1],p[0]]}
function toWgs(lat,lng){var p=gcj02ToWgs84Exact(+lng,+lat,true);return[p[1],p[0]]}
function build(form){
 if(enhanced.has(form)||!window.L)return;
 var old=$q('#adminPickerMap',form),latInput=form.lat,lngInput=form.lng;
 if(!old||!latInput||!lngInput)return;
 enhanced.add(form);
 var box=old.cloneNode(false);old.parentNode.replaceChild(box,old);
 var head=box.parentNode.querySelector('.admin-picker-head');
 if(head){head.insertAdjacentHTML('beforeend','<div class="admin-picker-tools"><select class="admin-picker-base" aria-label="地图底图"><option value="auto">自动底图</option><option value="amap">高德标准（大陆）</option><option value="osm">全球 OSM</option><option value="osmglobal">Esri 国际街道</option>'+((mapConfig&&mapConfig.tencent_enabled)?'<option value="tencent">腾讯标准（大陆）</option>':'')+((mapConfig&&mapConfig.tianditu_enabled)?'<option value="tianditu">天地图标准</option>':'')+'</select><button type="button" class="admin-picker-full" title="全屏选点" aria-label="全屏选点">⛶</button></div>');}
 var baseSelect=$q('.admin-picker-base',box.parentNode),full=$q('.admin-picker-full',box.parentNode);
 var initialLat=isFinite(+latInput.value)?+latInput.value:39.9042,initialLng=isFinite(+lngInput.value)?+lngInput.value:116.4074;
 var map=L.map(box,{zoomControl:true,worldCopyJump:true,maxZoom:20}).setView([initialLat,initialLng],isFinite(+latInput.value)?13:4);
 var layers={osm:L.tileLayer('https://tile.openstreetmap.de/{z}/{x}/{y}.png',{maxZoom:20,keepBuffer:3,updateWhenIdle:true,attribution:'OpenStreetMap'}),osmglobal:L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Street_Map/MapServer/tile/{z}/{y}/{x}',{maxZoom:20,maxNativeZoom:19,keepBuffer:3,updateWhenIdle:true,attribution:'Esri World Street Map'}),amap:L.tileLayer('https://webrd0{s}.is.autonavi.com/appmaptile?lang=zh_cn&size=1&scale=1&style=8&x={x}&y={y}&z={z}',{subdomains:'1234',maxZoom:18,keepBuffer:2,attribution:'高德地图'}),tencent:L.tileLayer('../api/tencent-tile.php?z={z}&x={x}&y={y}',{maxZoom:19,maxNativeZoom:19,keepBuffer:3,updateWhenIdle:true,attribution:'腾讯地图'}),tianditu:L.layerGroup([L.tileLayer('../api/tianditu-tile.php?z={z}&x={x}&y={y}&layer=vec',{maxZoom:20,maxNativeZoom:18,keepBuffer:3,updateWhenIdle:true,attribution:'天地图'}),L.tileLayer('../api/tianditu-tile.php?z={z}&x={x}&y={y}&layer=cva',{maxZoom:20,maxNativeZoom:18,keepBuffer:3,updateWhenIdle:true,attribution:'天地图'})])};
 var active='',pin,programmatic=false;
 function effective(){var v=baseSelect.value;if(v==='auto')return isMainland(+latInput.value,+lngInput.value)?'amap':'osmglobal';if(v==='tencent'&&mapConfig&&mapConfig.tencent_enabled&&isMainland(+latInput.value,+lngInput.value))return 'tencent';if(v==='tianditu'&&mapConfig&&mapConfig.tianditu_enabled&&isMainland(+latInput.value,+lngInput.value))return 'tianditu';if(v==='osm')return 'osm';if(v==='osmglobal')return 'osmglobal';return v==='amap'&&isMainland(+latInput.value,+lngInput.value)?'amap':'osmglobal'}
 function setLayer(fly){var next=effective();if(next===active)return;var hadActive=!!active,oldCenter=map.getCenter(),oldWgs=active==='amap'||active==='tencent'?toWgs(oldCenter.lat,oldCenter.lng):[oldCenter.lat,oldCenter.lng];if(active)map.removeLayer(layers[active]);active=next;layers[active].addTo(map);if(fly||!hadActive){var c=active==='amap'||active==='tencent'?toGcj(oldWgs[0],oldWgs[1]):oldWgs;map.setView(c,map.getZoom(),{animate:false});}syncPin(false)}
 function displayForWgs(lat,lng){return active==='amap'||active==='tencent'?toGcj(lat,lng):[lat,lng]}
 function wgsForDisplay(lat,lng){return active==='amap'||active==='tencent'?toWgs(lat,lng):[lat,lng]}
 function syncPin(fly){var lat=+latInput.value,lng=+lngInput.value;if(!isFinite(lat)||!isFinite(lng))return;var d=displayForWgs(lat,lng);if(!pin){pin=L.marker(d,{draggable:true}).addTo(map);pin.on('dragend',function(){var p=pin.getLatLng(),w=wgsForDisplay(p.lat,p.lng);setPoint(w[0],w[1],false)});}else pin.setLatLng(d);var label=$q('#pickerCoords',form);if(label)label.textContent='WGS-84：'+lat.toFixed(6)+', '+lng.toFixed(6)+(active==='amap'||active==='tencent'?'腾讯/高德大陆底图':'全球 WGS-84 底图');if(fly)map.flyTo(d,Math.max(map.getZoom(),13),{duration:.35});}
 function setPoint(lat,lng,fly){lat=+lat;lng=+lng;if(!isFinite(lat)||!isFinite(lng)||Math.abs(lat)>90||Math.abs(lng)>180)return;latInput.value=lat.toFixed(7);lngInput.value=lng.toFixed(7);setLayer(fly);syncPin(fly)}
 map.on('click',function(e){var w=wgsForDisplay(e.latlng.lat,e.latlng.lng);setPoint(w[0],w[1],false);var hint=$q('#geoHint',form);if(hint)hint.textContent='已从'+(active==='amap'||active==='tencent'?'腾讯/高德大陆底图':'全球 WGS-84 底图')+'选点并回填 WGS-84 坐标。'});
 function inputChanged(axis){var v=parseFloat(axis==='lat'?latInput.value:lngInput.value);if(!isFinite(v))return;setPoint(axis==='lat'?v:+latInput.value,axis==='lng'?v:+lngInput.value,true)}
 latInput.addEventListener('change',function(){inputChanged('lat')});lngInput.addEventListener('change',function(){inputChanged('lng')});form.addEventListener('picker:point',function(){setPoint(+latInput.value,+lngInput.value,true)});baseSelect.onchange=function(){setLayer(true)};
 full.onclick=function(){var section=box.closest('.admin-picker');if(document.fullscreenElement){document.exitFullscreen();return}if(section&&section.requestFullscreen)section.requestFullscreen().catch(function(){section.classList.toggle('admin-picker-fallback-full')});else if(section)section.classList.toggle('admin-picker-fallback-full')};document.addEventListener('fullscreenchange',function(){setTimeout(function(){map.invalidateSize()},100)});setPoint(initialLat,initialLng,false);setTimeout(function(){map.invalidateSize()},160);
}
function scan(){if(mapConfig===null)return;var f=document.getElementById('placeForm');if(f)build(f)}
function loadConfig(){fetch('../api/admin-map-config.php',{credentials:'same-origin',cache:'no-store'}).then(function(r){return r.json()}).then(function(j){mapConfig=j&&j.data||{tencent_enabled:false,tencent_key:''};scan()}).catch(function(){mapConfig={tencent_enabled:false,tencent_key:''};scan()})}
new MutationObserver(scan).observe(document.body,{childList:true,subtree:true});setInterval(scan,500);loadConfig();
})();
