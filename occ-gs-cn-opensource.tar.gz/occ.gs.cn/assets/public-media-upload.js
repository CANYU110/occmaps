(function(){
'use strict';
function esc(v){return String(v||'').replace(/[&<>"']/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})}
window.initPublicMediaUploader=function(form){
 var hidden=form.querySelector('[name="media_json"]'),drop=form.querySelector('.public-media-drop'),list=form.querySelector('.public-media-list'),rows=[],busy=false;
 if(!hidden||!drop||!list)return;
 try{var seed=JSON.parse(hidden.value||'[]');if(Array.isArray(seed))rows=seed.filter(function(x){return x&&x.url})}catch(e){}
 function sync(){hidden.value=JSON.stringify(rows)}
 function reorder(from,to){if(from===to||from<0||to<0)return;var item=rows.splice(from,1)[0];rows.splice(to,0,item);sync();render()}
 function bindPointer(item){
  item.addEventListener('pointerdown',function(e){
   if(e.target.closest('button'))return;
   e.preventDefault();var from=Number(item.dataset.index),last=from;item.classList.add('is-pointer-dragging');
   try{item.setPointerCapture(e.pointerId)}catch(x){}
   function move(ev){var target=document.elementFromPoint(ev.clientX,ev.clientY);target=target&&target.closest('.public-media-item');if(!target)return;var to=Number(target.dataset.index);if(isFinite(to)&&to!==last){reorder(from,to);from=to;last=to}}
   function end(){document.removeEventListener('pointermove',move);document.removeEventListener('pointerup',end);document.removeEventListener('pointercancel',end);item.classList.remove('is-pointer-dragging')}
   document.addEventListener('pointermove',move,{passive:false});document.addEventListener('pointerup',end);document.addEventListener('pointercancel',end);
  })
 }
 function render(){
  list.innerHTML=rows.map(function(r,i){return'<div class="public-media-item" data-index="'+i+'">'+(r.type==='video'?'<video muted preload="metadata" src="'+esc(r.url)+'"></video>':'<img src="'+esc(r.url)+'" alt="">')+'<b>☷ '+esc(r.type==='video'?'视频':'图片')+'</b><button type="button" aria-label="删除">×</button></div>'}).join('');
  list.querySelectorAll('.public-media-item').forEach(function(el){var i=Number(el.dataset.index);bindPointer(el);el.querySelector('button').onclick=function(e){e.stopPropagation();rows.splice(i,1);sync();render()}});sync()
 }
 function uploadOne(file){var data=new FormData();data.append('file',file);return fetch('api/media-upload.php',{method:'POST',body:data,credentials:'same-origin'}).then(function(r){return r.text().then(function(t){var j;try{j=JSON.parse(t)}catch(e){throw Error('上传接口返回异常，请刷新页面重试')}if(!r.ok||j.code!==0)throw Error(j.msg||'上传失败');return j.data})})}
 function upload(files){if(busy)return;var selected=Array.prototype.slice.call(files||[]).filter(function(file){return /^image\/(jpeg|png|webp|gif)$/i.test(file.type)||/\.(jpe?g|png|webp|gif)$/i.test(file.name)});if(selected.length!==(files&&files.length||0))alert('只支持 JPG、PNG、WebP、GIF 图片');if(!selected.length)return;busy=true;drop.classList.add('is-uploading');drop.querySelector('b').textContent='正在上传 '+selected.length+' 个文件…';Promise.all(selected.map(uploadOne)).then(function(data){data.forEach(function(d){rows.push({type:d.media_type,url:d.url})});render()}).catch(function(e){alert(e.message)}).finally(function(){busy=false;drop.classList.remove('is-uploading');drop.querySelector('b').textContent='点击选择文件'})}
 drop.onclick=function(e){if(!busy&&(e.target===drop||e.target.closest('b')))drop.querySelector('input').click()};
 drop.querySelector('input').onchange=function(e){upload(e.target.files);e.target.value=''};
 drop.ondragover=function(e){e.preventDefault();if(!busy)drop.classList.add('dragover')};drop.ondragleave=function(){drop.classList.remove('dragover')};drop.ondrop=function(e){e.preventDefault();drop.classList.remove('dragover');if(!busy)upload(e.dataTransfer.files)};
 render();
}
})();
