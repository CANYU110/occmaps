(function(){
'use strict';
function loadConfig(form){
  fetch('../api/community.php?action=submission_config',{cache:'no-store'}).then(function(r){return r.json()}).then(function(j){
    var d=j&&j.data||{};
    var a=form.querySelector('[name="submission_media_mode"]'),b=form.querySelector('[name="feedback_media_mode"]'),i=form.querySelector('[name="submission_email_code_interval"]'),h=form.querySelector('[name="submission_email_code_hourly_limit"]');
    if(a)a.value=d.media_mode||'optional';
    if(b)b.value=d.feedback_media_mode||'optional';
    if(i)i.value=d.code_interval||60;
    if(h)h.value=d.code_hourly_limit||5;
  }).catch(function(){});
}
function mount(){
  var form=document.querySelector('#communitySettingsForm');
  if(!form||form.querySelector('[name="submission_media_mode"]'))return;
  var block=document.createElement('div');
  block.innerHTML='<div class="cols"><div><label>投稿图片/视频</label><select name="submission_media_mode"><option value="hidden">不显示</option><option value="optional">选填</option><option value="required">必填</option></select></div><div><label>反馈图片/视频</label><select name="feedback_media_mode"><option value="hidden">不显示</option><option value="optional">选填</option><option value="required">必填</option></select></div></div><div class="cols"><div><label>验证码发送间隔（秒，最少60）</label><input type="number" min="60" max="86400" name="submission_email_code_interval" value="60"></div><div><label>每小时最多发送次数</label><input type="number" min="1" max="100" name="submission_email_code_hourly_limit" value="5"></div></div>';
  var anchor=form.querySelector('.check-row');
  if(anchor)anchor.parentNode.insertBefore(block,anchor);else form.insertBefore(block,form.firstChild);
  loadConfig(form);
}
var timer=setInterval(mount,300);setTimeout(function(){clearInterval(timer);mount()},10000);mount();
})();
